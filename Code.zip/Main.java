import java.util.*;

public class Main {
    public static void main(String[] args) {
//        Vertex A = new Vertex("A");
//        Vertex B = new Vertex("B");
//        Vertex C = new Vertex("C");
//        Vertex D = new Vertex("D");
//        Vertex E = new Vertex("E");
////        A.displayNeighbors();
////        B.displayNeighbors();
////        C.displayNeighbors();
////        D.displayNeighbors();
////        A.removeNeighbor(B);
////        B.removeNeighbor(C);
////        A.displayNeighbors();
////        B.displayNeighbors();
//        List<Vertex> vertList = new ArrayList<Vertex>();
//        vertList.add(A);
//        vertList.add(B);
//        vertList.add(C);
//        vertList.add(D);
//        vertList.add(E);
//
//        Map<Vertex[], Double> edges = new HashMap<Vertex[], Double>();
//        edges.put(new Vertex[]{A, B}, 1.0);
//        edges.put(new Vertex[]{B, C}, 2.0);
//        edges.put(new Vertex[]{C, D}, 7.0);
//        edges.put(new Vertex[]{D, A}, 3.0);
//        edges.put(new Vertex[]{A, C}, 2.0);
//        edges.put(new Vertex[]{C, A}, 3.0);
////
//        Graph G = new Graph("G", vertList, edges);
//        G.displayGraph();
////        List<Double> distances = new ArrayList<Double>();
////        distances.add(1.0);
////        distances.add(2.0);
////        distances.add(3.0);
////        distances.add(4.0);
//        DistancePath res = G.shortestPath(A, C);
//        System.out.println(res.getDistance());
//        System.out.println(res.getPath());
        Vertex A = new Vertex("A");
        Vertex B = new Vertex("B");
        Vertex C = new Vertex("C");
        Vertex D = new Vertex("D");
        Vertex E = new Vertex("E");
        Vertex F = new Vertex("F");
        Vertex G = new Vertex("G");
        List<Vertex> vertices = new ArrayList<>();
        vertices.add(A);
        vertices.add(B);
        vertices.add(C);
        vertices.add(D);
        vertices.add(E);
        vertices.add(F);
        vertices.add(G);

        Map<Vertex[], Double> edges = new HashMap<Vertex[], Double>();
        edges.put(new Vertex[]{A, B}, 5.0);
        edges.put(new Vertex[]{A, E}, 4.0);
        edges.put(new Vertex[]{A, D}, 3.0);
        edges.put(new Vertex[]{D, G}, 8.0);
        edges.put(new Vertex[]{G, C}, 3.0);
        edges.put(new Vertex[]{G, F}, 4.0);
        edges.put(new Vertex[]{E, C}, 6.0);
        edges.put(new Vertex[]{E, F}, 2.0);
        edges.put(new Vertex[]{B, E}, 3.0);
        edges.put(new Vertex[]{B, F}, 9.0);
        edges.put(new Vertex[]{D, E}, 5.0);
        edges.put(new Vertex[]{D, C}, 7.0);
        Graph graph = new Graph("G", vertices, edges);
        DistanceReference res = graph.Dijkstra(A);
        System.out.println(res.getDist());

    }
}