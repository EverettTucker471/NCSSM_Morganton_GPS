import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class OrderedDictionary<K, V> {
    List<K> keys;
    List<V> values;

    /**
     * Default constructor
     */
    public OrderedDictionary() {
        keys = new ArrayList<K>();
        values = new ArrayList<V>();
    }

    /**
     * Constructor taking keys and values, lists of the same size
     * @param keys the keys of the ordered dictionary
     * @param values the values of the ordered dictionary
     */
    public OrderedDictionary(List<K> keys, List<V> values) {
        this();
        if (keys != null && values != null) {
            if (keys.size() == values.size()) {
                Iterator<K> keysItr = keys.iterator();
                Iterator<V> valuesItr = values.iterator();
                while (keysItr.hasNext()) {
                    this.add(keysItr.next(), valuesItr.next());
                }
            } else {
                throw new IllegalArgumentException("Keys and Values should be of the same length");
            }
        } else if (!(keys == null && values == null)) {
            throw new IllegalArgumentException("Exactly one of Keys and Values cannot be null");
        }
    }

    /**
     * Gives the string representation of dictionary
     * @return the string representation
     */
    public String toString() {
        StringBuilder rtn = new StringBuilder();
        for (int i = 0; i < keys.size(); i++) {
            rtn.append(keys.get(i).toString()).append("-").append(values.get(i).toString()).append(", ");
        }
        return rtn.toString();
    }

    /**
     * FIX BECAUSE OF POTENTIAL DUPLICATE KEYS. Adds new elements to the dictionary at the specified index. O(n) time complexity.
     * @param key the key of the new element
     * @param value the value of the new element
     * @param index the index of insertion
     * @return the boolean indicating a change
     */
    public boolean add(K key, V value, int index) {
        if (key != null && value != null) {
            if (0 <= index && index <= keys.size()) {
                // Find the index of key in keys
                int duplicateIndex = -1;
                int count = 0;
                for (K k : keys) {
                    if (k == key) {
                        duplicateIndex = count;
                        break;
                    }
                    count++;
                }

                // Replace or add new key-value-index triple?
                if (duplicateIndex == -1) {
                    keys.add(index, key);
                    values.add(index, value);
                } else {
                    values.set(duplicateIndex, value);
                }
                return true;
            } else {
                throw new IndexOutOfBoundsException("Index i should have 0 <= i <= size");
            }
        } else {
            throw new IllegalArgumentException("Keys and Values should not be null");
        }
    }

    /**
     * Adds new elements to the end of the dictionary. O(1) time complexity.
     * @param key the key of the new element
     * @param value the value of the new element
     * @return the boolean indicating a change
     */
    public boolean add(K key, V value) {
        return add(key, value, keys.size());
    }

    /**
     * Swaps the elements of the dictionary of indices i, j. O(1) time complexity
     * @param i the first element index
     * @param j the second element index
     * @return the boolean indicating a change
     */
    public boolean swap(int i, int j) {
        if (i < 0 || i >= keys.size() || j < 0 || j >= keys.size()) {
            throw new IndexOutOfBoundsException("i and j should be between 0, inclusive, and size, non-inclusive");
        } else {
            K tempKey = keys.get(i);
            keys.set(i, keys.get(j));
            keys.set(j, tempKey);
            V tempValue = values.get(i);
            values.set(i, values.get(j));
            values.set(j, tempValue);
            return true;
        }
    }

    /**
     * Gets the corresponding value to the key. O(n) time complexity.
     * @param key the key
     * @return the value
     */
    public V get(K key) {
        int index = -1;
        int count = 0;
        for (K k : keys) {
            if (k == key) {
                index = count;
                break;
            }
            count ++;
        }
        if (index >= 0) {
            return values.get(index);
        } else {
            return null;
        }
    }

    /**
     * Gets the key at the specified index
     * @param index the specified index
     * @return the key at the specified index
     */
    public K getKey(int index) {
        if (index < 0 || index >= keys.size()) {
            throw new IndexOutOfBoundsException("index should be between 0, inclusive, and size, non-inclusive");
        } else {
            return keys.get(index);
        }
    }

    /**
     * Gets the value at the specified index
     * @param index the specified index
     * @return the value at the specified index
     */
    public V getValue(int index) {
        if (index < 0 || index >= keys.size()) {
            throw new IndexOutOfBoundsException("index should be between 0, inclusive, and size, non-inclusive");
        } else {
            return values.get(index);
        }
    }

    /**
     * Gets the index of key
     * @param key the key in question
     * @return the index of key, -1 if not found
     */
    public int indexOfKey(K key) {
        int count = 0;
        int rtn = -1;
        for (K k : keys) {
            if (k == key) {
                rtn = count;
                return rtn;
            } else {
                count += 1;
            }
        }
        return rtn;
    }

}
