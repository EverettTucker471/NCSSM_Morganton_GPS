import java.sql.Array;
import java.util.*;

public class Graph {
    private String name;
    private List<Vertex> vertices;
    private Map<Double, Vertex> IDToVertex;

    // Undirected weights of edges
    private Map<Double, Double> edges;

    /**
     * Default constructor
     */
    public Graph() {
        this.name = "";
        this.vertices = new ArrayList<Vertex>();
        this.IDToVertex = new HashMap<Double, Vertex>();
        this.edges = new HashMap<Double, Double>();
    }

    /**
     * Constructor taking a name
     *
     * @param name the name of the graph
     */
    public Graph(String name) {
        this();
        this.name = Objects.requireNonNullElse(name, "");
    }

    /**
     * Constructor taking a name and vertices
     *
     * @param name     the name of the graph
     * @param vertices the vertices of the graph. Vertices are not copied. Vertices should have no neighbors.
     */
    public Graph(String name, List<Vertex> vertices) {
        this(name);
        if (vertices != null) {
            for (Vertex vertex : vertices) {
                if (vertex.neighborIDs().length == 0) {
                    this.vertices.add(vertex);
                    IDToVertex.put(vertex.getID(), vertex);
                } else {
                    throw new IllegalArgumentException("Vertices array should be of neighborless vertices");
                }
            }
        }
    }

    /**
     * Constructor taking graph name, graph vertices, and weighted graph edges
     *
     * @param name     the name of the graph
     * @param vertices the vertices of the graph. Vertices are not copied. Vertices should have no neighbors.
     * @param edges    the edges of the graph. edges is not copied. Weighted edges should be undirected. Vertices adjacent to the edges should be in the vertices parameter.
     */
    public Graph(String name, List<Vertex> vertices, Map<Vertex[], Double> edges) {
        this(name, vertices);
        if (edges != null) {
            // Copy the input edges HashMap
            for (Vertex[] vertPair : edges.keySet()) {
                double weight = edges.get(vertPair);
                if (!(this.replaceAddEdge(vertPair[0], vertPair[1], weight))) {
                    throw new IllegalArgumentException("Vertices adjacent to the edges should be of vertices parameter");
                }
            }
            // Add the correct neighbors given the edges
            for (Vertex[] vertPair : edges.keySet()) {
                vertPair[0].addNeighbor(vertPair[1]);
            }
        }
    }

    /**
     * Displays the graph by displaying the neighbors of each vertex of the graph
     */
    public void displayGraph() {
        System.out.println("The data of graph " + name + "\n");
        System.out.println("The Vertices: ");
        for (Vertex vert : vertices) {
            vert.displayNeighbors();
        }
        System.out.print("\n");
        System.out.println("The edges: ");
        for (int i = 0; i < vertices.size(); i++) {
            for (int j = i; j < vertices.size(); j++) {
                Double weight = edges.get(vertices.get(i).getID() * vertices.get(j).getID());
                if (weight != null) {
                    System.out.print(vertices.get(i).getName() + "-" + vertices.get(j).getName() + ": " + weight + ", ");
                }
            }
        }
//        System.out.println(edges);
        System.out.print("\n");
        System.out.println("\n\n");
    }

    /**
     * Getter of graph name
     * @return the name of the graph
     */
    public String getName() {
        return name;
    }

    /**
     * Creates an edge of first-second, overwriting the previous edge or making a new one
     *
     * @param first  any adjacent vertex of the edge
     * @param second the other adjacent vertex of the edge
     * @param weight the weight of the edge
     * @return the boolean indicating a change
     */
    public boolean replaceAddEdge(Vertex first, Vertex second, double weight) {
        if (this.isVertex(first) && this.isVertex(second)) {
            edges.put(first.getID() * second.getID(), weight);
            first.addNeighbor(second);
            return true;
        } else {
            return false;
        }
    }

    /**
     * Removes the edge consisting of vertices first, second
     * @param first an adjacent vertex of the desired edge
     * @param second the other adjacent vertex
     * @return the boolean indicating change
     */
    public boolean removeEdge(Vertex first, Vertex second) {
        int prevSize = edges.size();
        edges.remove(first.getID() * second.getID());
        first.removeNeighbor(second);
        return edges.size() < prevSize;
    }

    /**
     * Removes the edge consisting of vertices first, second having the input IDs
     * @param firstID the ID of the first vertex
     * @param secondID the ID of the second vertex
     * @return the boolean indicating a change
     */
    public boolean removeEdge(double firstID, double secondID) {
        int prevSize = edges.size();
        edges.remove(firstID * secondID);
        IDToVertex.get(firstID).removeNeighbor(IDToVertex.get(secondID));
        return edges.size() < prevSize;
    }

    /**
     * Gives the weight of an edge given the edge's neighbors
     * @param first an adjacent vertex of the edge
     * @param second the other adjacent vertex
     * @return the weight of the edge
     */
    public double edgeWeight(Vertex first, Vertex second) {
        Double weightObj = edges.get(first.getID() * second.getID());
        return Objects.requireNonNullElse(weightObj, Double.MAX_VALUE);
    }

    /**
     * Getter for array of IDs of neighbors
     * @param vertex the vertex of graph whose neighbor IDs we want
     * @return the neighbors ID array, null if vertex is not in graph
     */
    public double[] neighborsOf(Vertex vertex) {
        if (this.isVertex(vertex)) {
            return vertex.neighborIDs();
        } else {
            return null;
        }
    }

    /**
     * Determines whether vertex is already a vertex of the graph
     * @param vertex the vertex in question
     * @return the boolean indicating whether vertex is of graph
     */
    private boolean isVertex(Vertex vertex) {
        boolean contained = false;
        for (Vertex vert : vertices) {
            if (vertex == vert) {
                contained = true;
                break;
            }
        }
        return contained;
    }

    /**
     * Adds a vertex to the graph
     * @param toAdd the vertex to add
     * @return the boolean indicating a change
     */
    public boolean addVertex(Vertex toAdd) {
        if (!(this.isVertex(toAdd))) {
            vertices.add(toAdd);
            IDToVertex.put(toAdd.getID(), toAdd);
            return true;
        } else {
            return false;
        }
    }

    /**
     * Removes toRemove and its adjacent edges from the graph
     * @param toRemove the vertex to remove
     * @return the boolean indicating a change
     */
    public boolean removeVertex(Vertex toRemove) {
        if (this.isVertex(toRemove)) {
            for (double id : toRemove.neighborIDs()) {
                this.removeEdge(IDToVertex.get(id), toRemove);
            }
            vertices.remove(toRemove);
            return true;
        } else {
            return false;
        }
    }

    /**
     * Applies Dijkstra's algorithm from vertex source
     * @param source the starting vertex
     * @return the list of distances and references corresponding to all shortest paths and their lengths
     */
    public DistanceReference Dijkstra(Vertex source) {
        if (isVertex(source)) {
            // Initialize sets and mappings
            List<Vertex> unvisited = new ArrayList<>();
            Map<Vertex, Double> dist = new HashMap<>();
            Map<Vertex, Vertex> prev = new HashMap<>();
            for (Vertex vertex : vertices) {
                dist.put(vertex, Double.MAX_VALUE);
                prev.put(vertex, null);
                unvisited.add(vertex);
            }

            dist.put(source, 0.0);

            while (unvisited.size() != 0) {
                // Remove and get the smallest distance element of unvisited vertices
                Vertex minDistVert = unvisited.get(0);
                double minDist = dist.get(minDistVert);
                for (Vertex vertex : unvisited) {
                    double currDist = dist.get(vertex);
                    if (currDist < minDist) {
                        minDistVert = vertex;
                        minDist = currDist;
                    }
                }
                unvisited.remove(minDistVert);

                for (double neighborID : minDistVert.neighborIDs()) {
                    Vertex neighbor = IDToVertex.get(neighborID);
                    if (unvisited.contains(neighbor)) {
                        double alt = dist.get(minDistVert) + edges.get(neighborID * minDistVert.getID());
                        if (alt < dist.get(neighbor)) {
                            dist.put(neighbor, alt);
                            prev.put(neighbor, minDistVert);
                        }
                    }
                }
            }
            return new DistanceReference(dist, prev);
        } else {
            throw new IllegalArgumentException("source should be a vertex of this graph");
        }
    }

    /**
     * Finds a shortest path from source to target
     * @param source the start vertex
     * @param target the end vertex
     * @return the distance and path from source to target
     */
    public DistancePath shortestPath(Vertex source, Vertex target) {
        if (isVertex(source) && isVertex(target)) {
            // Initialize sets and mappings
            List<Vertex> unvisited = new ArrayList<>();
            Map<Vertex, Double> dist = new HashMap<>();
            Map<Vertex, Vertex> prev = new HashMap<>();
            for (Vertex vertex : vertices) {
                dist.put(vertex, Double.MAX_VALUE);
                prev.put(vertex, null);
                unvisited.add(vertex);
            }

            dist.put(source, 0.0);

            while (unvisited.size() != 0) {
                // Remove and get the smallest distance element of unvisited vertices
                Vertex minDistVert = unvisited.get(0);
                double minDist = dist.get(minDistVert);
                for (Vertex vertex : unvisited) {
                    double currDist = dist.get(vertex);
                    if (currDist < minDist) {
                        minDistVert = vertex;
                        minDist = currDist;
                    }
                }
                unvisited.remove(minDistVert);
                if (minDistVert == target) {
                    List<Vertex> rtn = new ArrayList<>();
                    Vertex pointer = target;
                    while (pointer != null) {
                        rtn.add(0, pointer);
                        pointer = prev.get(pointer);
                    }
                    return new DistancePath(dist.get(minDistVert), rtn);
                }

                for (double neighborID : minDistVert.neighborIDs()) {
                    Vertex neighbor = IDToVertex.get(neighborID);
                    if (unvisited.contains(neighbor)) {
                        double alt = dist.get(minDistVert) + edges.get(neighborID * minDistVert.getID());
                        if (alt < dist.get(neighbor)) {
                            dist.put(neighbor, alt);
                            prev.put(neighbor, minDistVert);
                        }
                    }
                }
            }
            return new DistancePath(-1, null);
        } else {
            throw new IllegalArgumentException("source should be a vertex of this graph");
        }
    }
}
