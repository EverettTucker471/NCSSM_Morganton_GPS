public class MathLogic {
}
