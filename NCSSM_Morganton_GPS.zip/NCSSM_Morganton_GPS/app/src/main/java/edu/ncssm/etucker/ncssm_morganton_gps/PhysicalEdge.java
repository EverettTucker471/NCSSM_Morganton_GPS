package edu.ncssm.etucker.ncssm_morganton_gps;

import java.util.ArrayList;

public class PhysicalEdge {
    private ArrayList<PhysicalPoint> points = new ArrayList<>();
    private String name;
    private double distance;

    public PhysicalEdge(ArrayList<PhysicalPoint> p, String name) {
        if (p != null && p.size() > 0) {
            this.points.addAll(p);
        } else {
            throw new IllegalArgumentException("Physical point array should be nonnull");
        }
        if (name != null && !name.isEmpty()) {
            this.name = name;
        } else {
            throw new IllegalArgumentException("Name should be nonnull and nonempty");
        }
        this.distance = this.findDistance();
    }

    public double findDistance() {
        double rtn = 0;
        for (int i = 0; i < this.points.size() - 1; i++) {
            rtn += this.points.get(i).computeDistance(this.points.get(i+1));
        }
        return rtn;
    }

    public double getDistance() {
        return this.distance;
    }

    public String getName() {
        return this.name;
    }

    public boolean setName(String n) {
        boolean rtn = false;
        if (n != null && !n.isEmpty()) {
            this.name = n;
            rtn = true;
        }
        return rtn;
    }

    public boolean setPoints(ArrayList<PhysicalPoint> p) {
        boolean rtn = false;
        if (p != null) {
            this.points.addAll(p);
            rtn = true;
        }
        return rtn;
    }

    public String toString() {
        StringBuilder rtn = new StringBuilder(this.name + " " + this.distance);
        for (int i = 0; i < this.points.size(); i++) {
            rtn.append(this.points.get(i).toString());
        }
        return rtn.toString();
    }
}
