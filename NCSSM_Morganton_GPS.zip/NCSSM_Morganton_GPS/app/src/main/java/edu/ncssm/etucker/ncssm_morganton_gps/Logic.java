package edu.ncssm.etucker.ncssm_morganton_gps;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Arrays;

public class Logic {
    private ArrayList<PhysicalEdge> physicalEdgeList = new ArrayList<>();
    private ArrayList<PhysicalPoint> physicalPointList;

    public Logic() {}

    public ArrayList<PhysicalEdge> getPhysicalEdges() {
        return physicalEdgeList;
    }

    public ArrayList<PhysicalPoint> getPhysicalPoints() {
        return physicalPointList;
    }

    public boolean addPointOfInterest(double lat, double lon) {
        physicalPointList.add(new PhysicalPoint(lat, lon));
        return true;
    }

    // Maybe make another POI setter that takes a json object

    public void addPhysicalEdge(JSONObject json) throws JSONException {
        String key = json.keys().next();

        JSONArray arr = json.getJSONArray(key);
        ArrayList<PhysicalPoint> point_list = new ArrayList<>();
        for (int i = 0; i < arr.length(); i++) {
            String[] lat_lon = ((String) arr.get(i)).split(" ", 2);
            PhysicalPoint temp_point = new PhysicalPoint(Double.parseDouble(lat_lon[0]), Double.parseDouble(lat_lon[1]));
            point_list.add(temp_point);
        }
        physicalEdgeList.add(new PhysicalEdge(point_list, key));
        // Traverse the JSONArray and create a new edge with the coordinates
    }

    public void addPoint(JSONObject json) throws JSONException {
        String key = ((ArrayList<String>) json.keys()).get(0);
        JSONArray arr = json.getJSONArray(key);
        physicalPointList.add(new PhysicalPoint((Double) arr.get(0), (Double) arr.get(1)));
    }

    // This is the large function that initializes all the paths when the app is launched
    public void initializeEdges(String edge_string) throws JSONException {
        ArrayList<String> edges = new ArrayList<>();
        for (String e : edge_string.split("\n", edge_string.length())) {
            JSONObject json = new JSONObject(e);
            addPhysicalEdge(json);
        }
    }

    public void initializePoints(String point_string) throws JSONException {
        ArrayList<String> points = new ArrayList<>();
        for (String p : point_string.split("\n", point_string.length())) {
            JSONObject json = new JSONObject(p);
            addPoint(json);
        }
    }

    public double getDistanceFromIndex(int index) {
        if (index >= 0 && index < physicalEdgeList.size()) {
            return physicalEdgeList.get(index).getDistance();
        }
        return 0;
    }
}
