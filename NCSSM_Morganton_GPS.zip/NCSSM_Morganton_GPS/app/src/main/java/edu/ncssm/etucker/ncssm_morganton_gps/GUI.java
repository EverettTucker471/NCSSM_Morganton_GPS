package edu.ncssm.etucker.ncssm_morganton_gps;

import static android.content.Context.SENSOR_SERVICE;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.RotateDrawable;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Debug;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;

import java.text.DecimalFormat;
import java.util.ArrayList;

public class GUI extends SurfaceView {

    private static int canvasWidth = 1800;
    private static int canvasHeight = 2207;
    private static int maplength;
    private int poiRadius = 15;
    private float mapScale = 1f;
    private static int mapRotation;
    private MainActivity.Gyro gyro;
    private int[] dAnchorpoint;
    private int[] rAnchorpoint;
    private int[] personPos;
    private Canvas bitmapCanvas;
    private ArrayList<double[]> POIs = new ArrayList<>();
    private ArrayList<int[]> FixedPOIs = new ArrayList<>();
    private ArrayList<double[]> POIsPersonPos = new ArrayList<>();

    private static double minLongitude = -81.68999631296752;
    private static double maxLongitude  = -81.68464209872632;
    private static double minLatitude = 35.73190165046239;
    private static double maxLatitude = 35.726880384141765;

    private String coordinate;
    private double latitude;
    private double longitude;

    public GUI(Context context) {
        super(context);
    }

    public GUI(Context context, AttributeSet attrs) {
        super(context, attrs);
        setWillNotDraw(false);

        coordinate = "";

        SensorManager sensorManager = (SensorManager) context.getSystemService(SENSOR_SERVICE);
        Sensor sensorMag = sensorManager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD);
        Sensor sensorAcc = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        gyro = new MainActivity.Gyro();

        sensorManager.registerListener(gyro, sensorMag, SensorManager.SENSOR_DELAY_NORMAL);
        sensorManager.registerListener(gyro, sensorAcc, SensorManager.SENSOR_DELAY_NORMAL);
    }

    @Override
    protected void onDraw(Canvas c)
    {
        //Set the backround Color of the Canvas
        c.drawColor(Color.parseColor("#39b54a"));

        canvasWidth = c.getWidth();
        canvasHeight = c.getHeight();

        int oldCanvasWidth = canvasWidth;
        int oldCanvasHeight = canvasHeight;

        //mapScale = 1f;

        if(canvasWidth > canvasHeight)
        {
            maplength = canvasWidth;
        } else
        {
            maplength = canvasHeight;
        }



        rAnchorpoint = new int[]{c.getWidth()/2,c.getHeight()/2};
        dAnchorpoint = new int[]{
                c.getWidth()/2 - (int)((maplength/2) * mapScale),
                c.getHeight()/2 - (int)((maplength/2) * mapScale)
        };

        //Paint color
        Paint p = new Paint();
        p.setColor(Color.RED);

        //Gets Map from Resource File
        Drawable d = ContextCompat.getDrawable(getContext(), R.drawable.gps_v1_map);

        Bitmap bitmap = Bitmap.createBitmap(maplength, maplength, Bitmap.Config.ARGB_8888);

        personPos = convertToScreenCoordinates(latitude, longitude);

        //Creates a Canvas with a specified bitmap to Drawl into
        bitmapCanvas = new Canvas(bitmap);
        bitmapCanvas.scale(mapScale,mapScale,rAnchorpoint[0],rAnchorpoint[1]);
        bitmapCanvas.translate((rAnchorpoint[0] - personPos[0]),rAnchorpoint[1] - personPos[1]);


        //Sets the position of the Drawable
        d.setBounds(dAnchorpoint[0], dAnchorpoint[1], dAnchorpoint[0] + (int)(maplength * mapScale), dAnchorpoint[1] + (int)(maplength * mapScale));

        //Drawls the Map onto the Bitmap Canvas
        d.draw(bitmapCanvas);

        if(!POIs.isEmpty() & !POIsPersonPos.isEmpty())
        {
            for (double[] point: POIs) {
                drawPOI(bitmapCanvas, point, POIsPersonPos.get(POIs.indexOf(point)));
            }
        }

        Paint personColor = new Paint();
        personColor.setColor(Color.BLUE);
        bitmapCanvas.drawCircle(personPos[0], personPos[1], 20, personColor);

        c.drawBitmap(bitmap,0,0,null);

        Paint textColor = new Paint();
        textColor.setColor(Color.WHITE);
        textColor.setTextSize(100f);
        textColor.setTextAlign(Paint.Align.RIGHT);
        textColor.setTypeface(Typeface.DEFAULT_BOLD);
        c.drawText(coordinate, oldCanvasWidth - 30,oldCanvasHeight - 30, textColor);
    }
    public void rotateMap(int newRotation)
    {
        this.mapRotation = newRotation;
        invalidate();
    }

    public int[] convertToScreenCoordinates(double latitude, double longitude) {
        int x = (int) ((longitude - this.minLongitude) / (this.maxLongitude - this.minLongitude) * canvasWidth);
        int y = (int) ((latitude - this.minLatitude) / (this.maxLatitude - this.minLatitude) *canvasHeight);
        x += (x - rAnchorpoint[0]) * (mapScale - 1);
        y += (y - rAnchorpoint[1]) * (mapScale - 1);
        return new int[]{x, y};
    }

    public double[] convertScreenToCoordinates(int x, int y) {
        x -= (x - rAnchorpoint[0]) * (mapScale - 1);
        y -= (y - rAnchorpoint[1]) * (mapScale - 1);

        double longitude = ((double) x / canvasWidth) * (maxLongitude - minLongitude) + minLongitude;
        double latitude = ((double) y / canvasHeight) * (maxLatitude - minLatitude) + minLatitude;

        return new double[]{latitude, longitude};
    }

    private void drawPOI(Canvas canvas, double[] point, double[] anchor)
    {

        Paint poiColor = new Paint();
        poiColor.setColor(Color.rgb(128, 0, 255));

        int[] screenPoint = convertToScreenCoordinates(point[0], point[1]);
        int[] screenAnchor = convertToScreenCoordinates(anchor[0], anchor[1]);

        int changeX = screenAnchor[0] - screenPoint[0];
        int changeY = screenAnchor[1] - screenPoint[1];

        int currentX = screenAnchor[0] - changeX;
        int currentY = screenAnchor[1] - changeY;

        int changX1 = screenAnchor[0] - rAnchorpoint[0];
        int changeY1 = screenAnchor[1] - rAnchorpoint[1];

        int newX = currentX + changX1;
        int newY = currentY + changeY1;

        FixedPOIs.add(new int[]{newX, newY});

        canvas.drawCircle(newX, newY, poiRadius, poiColor);
        invalidate();
    }

    public void addPOI(double x, double y)
    {
        POIs.add(new double[]{x,y});
        invalidate();
    }

    public void addPersonPOI(double x, double y)
    {
        POIsPersonPos.add(new double[]{x,y});
        invalidate();
    }

    public void setPersonPos(double lat, double lon)
    {
        DecimalFormat decimalFormat = new DecimalFormat("0.000000");
        this.latitude = lat;
        this.longitude = lon;
        if((lat == 0) || (lon == 0))
        {
            lat = 35.72913026;
            lon = -81.68718064;
        }
        coordinate = ""+decimalFormat.format(lat)+", "+decimalFormat.format(lon)+"";
        invalidate();
    }

    public void setMapScale(float newScale)
    {
        this.mapScale = newScale;
        invalidate();
    }
    public void clearPOI()
    {
        POIs.clear();
        invalidate();
    }
    public void clearPOIAnchors()
    {
        POIsPersonPos.clear();
        invalidate();
    }
    public ArrayList<double[]> getPOIs()
    {
        return POIs;
    }
    public int getPoiRadius()
    {
        return poiRadius;
    }
    public ArrayList<int[]> getFixedPOIs() {
        return FixedPOIs;
    }
    public void removePOI(double[] point)
    {
        POIs.remove(point);
        invalidate();
    }
}
