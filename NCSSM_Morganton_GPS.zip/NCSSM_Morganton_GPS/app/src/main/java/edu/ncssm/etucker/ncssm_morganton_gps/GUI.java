package edu.ncssm.etucker.ncssm_morganton_gps;

import static android.content.Context.SENSOR_SERVICE;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.RotateDrawable;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Debug;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;

import java.text.DecimalFormat;
import java.util.ArrayList;

public class GUI extends SurfaceView {

    private static int canvasWidth = 1800;
    private static int canvasHeight = 2207;
    private static int maplength;
    private int poiRadius = 15;
    private float mapScale = 1f;
    private static int mapRotation;
    private MainActivity.Gyro gyro;
    private int[] dAnchorpoint;
    private int[] rAnchorpoint;
    private int[] personPos;
    private Canvas bitmapCanvas;
    private ArrayList<double[]> POIs = new ArrayList<>();
    private ArrayList<int[]> FixedPOIs = new ArrayList<>();
    private ArrayList<double[]> POIsPersonPos = new ArrayList<>();

    private static double minLongitude = -81.68999631296752;
    private static double maxLongitude  = -81.68464209872632;
    private static double minLatitude = 35.73190165046239;
    private static double maxLatitude = 35.726880384141765;

    private String coordinate;
    private double latitude;
    private double longitude;

    public GUI(Context context) {
        super(context);
    }

    public GUI(Context context, AttributeSet attrs) {
        super(context, attrs);
        setWillNotDraw(false);

        coordinate = "";

        SensorManager sensorManager = (SensorManager) context.getSystemService(SENSOR_SERVICE);
        Sensor sensorMag = sensorManager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD);
        Sensor sensorAcc = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        gyro = new MainActivity.Gyro();

        sensorManager.registerListener(gyro, sensorMag, SensorManager.SENSOR_DELAY_NORMAL);
        sensorManager.registerListener(gyro, sensorAcc, SensorManager.SENSOR_DELAY_NORMAL);
    }

    /**
     * Drawls to a canvas
     * @param c the canvas on which the background will be drawn
     */
    @Override
    protected void onDraw(Canvas c)
    {
        //Set the backround Color of the Canvas
        c.drawColor(Color.parseColor("#39b54a"));

        canvasWidth = c.getWidth();
        canvasHeight = c.getHeight();

        int oldCanvasWidth = canvasWidth;
        int oldCanvasHeight = canvasHeight;


        //Sets the map length to either the canvas width or height, depending on which one it bigger.
        if(canvasWidth > canvasHeight)
        {
            maplength = canvasWidth;
        } else
        {
            maplength = canvasHeight;
        }


        //Center point of the Canvas
        rAnchorpoint = new int[]{c.getWidth()/2,c.getHeight()/2};
        dAnchorpoint = new int[]{
                c.getWidth()/2 - (int)((maplength/2) * mapScale),
                c.getHeight()/2 - (int)((maplength/2) * mapScale)
        };

        //Paint color
        Paint p = new Paint();
        p.setColor(Color.RED);

        //Gets Map from Resource File
        Drawable d = ContextCompat.getDrawable(getContext(), R.drawable.gps_v1_map);

        //Makes a bitmap with a width and height of the mapLength variable
        Bitmap bitmap = Bitmap.createBitmap(maplength, maplength, Bitmap.Config.ARGB_8888);

        //Sets the persons position on screen depending on the latitude anf longitude
        personPos = convertToScreenCoordinates(latitude, longitude);

        //Creates a Canvas with a specified bitmap to Drawl into
        bitmapCanvas = new Canvas(bitmap);

        //Scales the bitmap canvas by the mapScale variable on both the x and y, with the rAnchorpoint being the center point
        bitmapCanvas.scale(mapScale,mapScale,rAnchorpoint[0],rAnchorpoint[1]);

        //Moves the bitmap canvas so that the player is in the center of the screen.
        bitmapCanvas.translate((rAnchorpoint[0] - personPos[0]),rAnchorpoint[1] - personPos[1]);


        //Sets the position of the Drawable
        d.setBounds(dAnchorpoint[0], dAnchorpoint[1], dAnchorpoint[0] + (int)(maplength * mapScale), dAnchorpoint[1] + (int)(maplength * mapScale));

        //Drawls the Map onto the Bitmap Canvas
        d.draw(bitmapCanvas);

        //Drawls the points of interest stored in the POIs Arraylist.
        if(!POIs.isEmpty() & !POIsPersonPos.isEmpty())
        {
            for (double[] point: POIs) {
                drawPOI(bitmapCanvas, point, POIsPersonPos.get(POIs.indexOf(point)));
            }
        }

        //Drawls the person onto the bitmap
        Paint personColor = new Paint();
        personColor.setColor(Color.BLUE);
        bitmapCanvas.drawCircle(personPos[0], personPos[1], 20, personColor);

        //Drawls the bitmap canvas onto the main canvas
        c.drawBitmap(bitmap,0,0,null);

        //Drawls the coordinates of the person in the bottom right of the screen
        Paint textColor = new Paint();
        textColor.setColor(Color.WHITE);
        textColor.setTextSize(100f);
        textColor.setTextAlign(Paint.Align.RIGHT);
        textColor.setTypeface(Typeface.DEFAULT_BOLD);
        c.drawText(coordinate, oldCanvasWidth - 30,oldCanvasHeight - 30, textColor);
    }

    /**
     * Sets the mapRotation variable to newRotation.
     * @param newRotation
     */
    public void rotateMap(int newRotation)
    {
        this.mapRotation = newRotation;
        invalidate();
    }

    /**
     * Converts latitude and longitude to screen coordinates
     * @param latitude
     * @param longitude
     * @return
     */
    public int[] convertToScreenCoordinates(double latitude, double longitude) {
        int x = (int) ((longitude - this.minLongitude) / (this.maxLongitude - this.minLongitude) * canvasWidth);
        int y = (int) ((latitude - this.minLatitude) / (this.maxLatitude - this.minLatitude) *canvasHeight);
        x += (x - rAnchorpoint[0]) * (mapScale - 1);
        y += (y - rAnchorpoint[1]) * (mapScale - 1);
        return new int[]{x, y};
    }

    /**
     * Converts the screen coordinates to actual coordinates on the map.
     * @param x
     * @param y
     * @return
     */
    public double[] convertScreenToCoordinates(int x, int y) {
        x -= (x - rAnchorpoint[0]) * (mapScale - 1);
        y -= (y - rAnchorpoint[1]) * (mapScale - 1);

        double longitude = ((double) x / canvasWidth) * (maxLongitude - minLongitude) + minLongitude;
        double latitude = ((double) y / canvasHeight) * (maxLatitude - minLatitude) + minLatitude;

        return new double[]{latitude, longitude};
    }

    /**
     * Drawls a Point of interest on the given canvas. canvas is the targeted Canvas, point
     * is the position of the desired point you want to drawl, and anchor is the position
     * of the person when the point was added. It acts as an anchor so that the Point of
     * interest dose not move when the player dose.
     * @param canvas
     * @param point
     * @param anchor
     */
    private void drawPOI(Canvas canvas, double[] point, double[] anchor)
    {

        Paint poiColor = new Paint();
        poiColor.setColor(Color.rgb(128, 0, 255));

        int[] screenPoint = convertToScreenCoordinates(point[0], point[1]);
        int[] screenAnchor = convertToScreenCoordinates(anchor[0], anchor[1]);

        int changeX = screenAnchor[0] - screenPoint[0];
        int changeY = screenAnchor[1] - screenPoint[1];

        int currentX = screenAnchor[0] - changeX;
        int currentY = screenAnchor[1] - changeY;

        int changX1 = screenAnchor[0] - rAnchorpoint[0];
        int changeY1 = screenAnchor[1] - rAnchorpoint[1];

        int newX = currentX + changX1;
        int newY = currentY + changeY1;

        FixedPOIs.add(new int[]{newX, newY});

        canvas.drawCircle(newX, newY, poiRadius, poiColor);
        invalidate();
    }

    /**
     * Adds point of interest to the POIs ArrayList. x is the latitude and y is the longitude.
     * @param x
     * @param y
     */
    public void addPOI(double x, double y)
    {
        POIs.add(new double[]{x,y});
        invalidate();
    }


    /**
     * Adds that anchor point to the point of interest just added.
     * @param x
     * @param y
     */
    public void addPersonPOI(double x, double y)
    {
        POIsPersonPos.add(new double[]{x,y});
        invalidate();
    }


    /**
     * Sets the person position based on the latitude and longitude.
     * @param lat
     * @param lon
     */
    public void setPersonPos(double lat, double lon)
    {
        DecimalFormat decimalFormat = new DecimalFormat("0.000000");
        this.latitude = lat;
        this.longitude = lon;
        if((lat == 0) || (lon == 0))
        {
            lat = 35.72913026;
            lon = -81.68718064;
        }
        coordinate = ""+decimalFormat.format(lat)+", "+decimalFormat.format(lon)+"";
        invalidate();
    }

    /**
     * Sets the mapScale variable to a new mapScale.
     * @param newScale
     */
    public void setMapScale(float newScale)
    {
        this.mapScale = newScale;
        invalidate();
    }

    /**
     * Clears the points of interest array list
     */
    public void clearPOI()
    {
        POIs.clear();
        invalidate();
    }

    /**
     * Clears the points of interest Anchorpoint array list
     */
    public void clearPOIAnchors()
    {
        POIsPersonPos.clear();
        invalidate();
    }

    /**
     * Returns the current POIs.
     * @return
     */
    public ArrayList<double[]> getPOIs()
    {
        return POIs;
    }

    /**
     * Returns the size of the points of interest made
     * @return
     */
    public int getPoiRadius()
    {
        return poiRadius;
    }

    /**
     * Removes a point of interest from POIs.
     * @param point
     */
    public void removePOI(double[] point)
    {
        POIs.remove(point);
        invalidate();
    }
    public ArrayList<double[]> POIsPersonPos(){
        return POIsPersonPos;
    }
    public int[] getPersonPos(){
        return personPos;
    }
}