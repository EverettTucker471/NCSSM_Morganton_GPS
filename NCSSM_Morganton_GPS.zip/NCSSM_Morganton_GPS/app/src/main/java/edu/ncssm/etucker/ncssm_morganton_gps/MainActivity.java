package edu.ncssm.etucker.ncssm_morganton_gps;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Objects;

public class MainActivity extends AppCompatActivity {
    Button startButton, endButton, poiButton, clearDataButton;
    TextView coordinateView, poiView;
    EditText nameInput;
    Logic l = new Logic();
    LocationManager locationManager;
    LocationListener locationListener;
    Context context;
    ArrayList<String> temp_path = new ArrayList<>();

    // This is some sample data from the
    String exampleData = "{\"ExampleEdge\":[\"43.00073166666667 -122.88323666666666\",\"43.003345 -122.87022\",\"43.00704833333333 -122.85957666666667\",\"43.00987166666667 -122.85271166666666\",\"43.017026666666666 -122.83983666666667\",\"43.021481666666666 -122.83314166666666\",\"43.02744333333333 -122.82610333333334\",\"43.032525 -122.82043833333333\",\"43.02592166666667 -122.80963833333334\"]}";

    // Move to logic maybe
    private void writeJSON(String path_name, ArrayList<String> path) throws JSONException, IOException {
        try {
            JSONObject physicalEdges = new JSONObject();
            JSONArray json_path = new JSONArray();
            for (int i = 0; i < path.size(); i++) {
                json_path.put(path.get(i));
            }
            physicalEdges.put(path_name, json_path);
            Log.d("JSON", physicalEdges.toString());

            String jsonPathString = physicalEdges.toString();

            // Another attempt - looks like it works
            writeToFile("PhysicalEdges.txt", readFromFile("PhysicalEdges.txt") + " \n " + jsonPathString);
            Log.d("OUTPUT", readFromFile("PhysicalEdges.txt"));

        } catch (JSONException e) {
            e.printStackTrace();
            Log.d("JSON", "JSON Error");
        }
    }

    private void writeToFile(String fileName, String contents) {
        File file_path = getApplicationContext().getFilesDir();
        try {
            FileOutputStream writer = new FileOutputStream(new File(file_path, fileName));
            writer.write(contents.getBytes());
            writer.close();
            Log.d("FILE", "File Written to txt");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @NonNull
    private String readFromFile(String fileName) {
        File path = getApplicationContext().getFilesDir();
        File readFrom = new File(path, fileName);
        byte[] rtn = new byte[(int) readFrom.length()];
        try {
            FileInputStream stream = new FileInputStream(readFrom);
            stream.read(rtn);
            return new String(rtn);
        } catch (Exception e) {
            e.printStackTrace();
            return e.toString();
        }
    }



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        locationListener = new GPSHandler();

        coordinateView = findViewById(R.id.coordinateView);
        poiView = findViewById(R.id.poiView);
        nameInput = findViewById(R.id.edgeNameInput);

        context = this;


        startButton = findViewById(R.id.startRecordingButton);
        startButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (ActivityCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                    String[] permissions = new String[] {Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION};
                    requestPermissions(permissions, 2);
                    return;
                }
                locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 5000, 10, locationListener);
                Log.d("GPS", "ACCESS GRANTED");

                // Create the objects from example data
                try {
                    JSONObject json = new JSONObject(exampleData);
                    l.addPhysicalEdge(json);
                    Log.d("DISTANCE", String.valueOf((int) l.getDistanceFromIndex(0)));
                    Log.d("JSON", json.toString());
                    Log.d("toString", l.getPhysicalEdges().get(0).toString());
                } catch (JSONException e) {
                    throw new RuntimeException(e);
                }
            }
        });

        endButton = findViewById(R.id.endRecordingButton);
        endButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                locationManager.removeUpdates(locationListener);
                try {
                    System.out.println("JSON Written Successfully");
                    writeJSON(String.valueOf(nameInput.getText()), temp_path);
                } catch (JSONException | IOException e) {
                    System.out.println("JSON or IO Error");
                    throw new RuntimeException(e);
                }
                temp_path.clear();
                nameInput.setText("");
            }
        });

        poiButton = findViewById(R.id.poiButton);
        poiButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String poi = temp_path.get(temp_path.size() - 1);
                JSONObject json = new JSONObject();
                try {
                    json.put((String) poiView.getText(), poi);
                    poiView.setText(json.toString());
                    writeToFile("PointsOfInterest.txt", readFromFile("PointsOfInterest")+ json);
                    Log.d("FILE", "Point of interest written"+json);
                } catch (JSONException e) {
                    e.printStackTrace();
                    throw new RuntimeException(e);
                }
            }
        });

        clearDataButton = findViewById(R.id.clearEverythingButton);
        clearDataButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                writeToFile("PointsOfInterest.txt", "");
                writeToFile("PhysicalEdges.txt", "");
                Log.d("DATA", "ALL DATA CLEARED");
            }
        });
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        for (int i = 0; i < permissions.length; i++) {
            if (!Objects.equals(permissions[i], Manifest.permission.ACCESS_FINE_LOCATION) && grantResults[i] != PackageManager.PERMISSION_GRANTED) {
                Log.d("GPS", "NOT GRANTED" + grantResults[i]);
            }
        }
    }

    private class GPSHandler implements LocationListener {
        @Override
        public void onLocationChanged(@NonNull Location location) {
            Log.d("GPS", "LOCATION CHANGED:" + location.getLatitude() + " " + location.getLongitude());
            coordinateView.setText(location.getLatitude() + " " + location.getLongitude());
            temp_path.add(location.getLatitude() + " " + location.getLongitude());
        }
    }
}