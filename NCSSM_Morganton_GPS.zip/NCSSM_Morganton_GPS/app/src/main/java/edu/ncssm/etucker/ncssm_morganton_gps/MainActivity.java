package edu.ncssm.etucker.ncssm_morganton_gps;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageManager;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.text.Layout;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.DragEvent;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.android.material.chip.ChipGroup;
import com.google.android.material.slider.Slider;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Objects;

public class MainActivity extends AppCompatActivity {
    private static final int PERMISSION_REQUEST_CODE = 1;
    LocationManager locationManager;
    LocationListener locationListener;
    Context context;
    ArrayList<String> temp_path = new ArrayList<>();
    public static GUI gui;
    public Slider scaleSlider;
    public Button addPOI;
    public Button clearPOI;
    public Button deletPOI;
    public Button okButton;
    public Button PopUpTextOk;
    public View mapLayout;
    public ChipGroup options;
    public ChipGroup addOptions;
    public ChipGroup PopUpTextChipGroup;
    public EditText newPOIname;
    public TextView POInameView;
    public TextView PopUpText;
    public int[] selectedPoint = new int[2];
    private static float mapRotation;
    private double lat;
    private double lon;
    public boolean addingPOI = false;
    public boolean isPointSelected = false;
    public ArrayList<String> pointNames = new ArrayList<String>();

    // This is some sample data from the
    String exampleData = "{\"ExampleEdge\":[\"43.00073166666667 -122.88323666666666\",\"43.003345 -122.87022\",\"43.00704833333333 -122.85957666666667\",\"43.00987166666667 -122.85271166666666\",\"43.017026666666666 -122.83983666666667\",\"43.021481666666666 -122.83314166666666\",\"43.02744333333333 -122.82610333333334\",\"43.032525 -122.82043833333333\",\"43.02592166666667 -122.80963833333334\"]}";

    public MainActivity() {}

    // Move to logic maybe
    private void writeJSON(String path_name, ArrayList<String> path) throws JSONException, IOException {
        try {
            JSONObject physicalEdges = new JSONObject();
            JSONArray json_path = new JSONArray();
            for (int i = 0; i < path.size(); i++) {
                json_path.put(path.get(i));
            }
            physicalEdges.put(path_name, json_path);
            Log.d("JSON", physicalEdges.toString());

            String jsonPathString = physicalEdges.toString();

            // Another attempt - looks like it works
            writeToFile("PhysicalEdges.txt", readFromFile("PhysicalEdges.txt") + " \n " + jsonPathString);
            Log.d("OUTPUT", readFromFile("PhysicalEdges.txt"));

        } catch (JSONException e) {
            e.printStackTrace();
            Log.d("JSON", "JSON Error");
        }
    }

    private void writeToFile(String fileName, String contents) {
        File file_path = getApplicationContext().getFilesDir();
        try {
            FileOutputStream writer = new FileOutputStream(new File(file_path, fileName));
            writer.write(contents.getBytes());
            writer.close();
            Log.d("FILE", "File Written to txt");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @NonNull
    private String readFromFile(String fileName) {
        File path = getApplicationContext().getFilesDir();
        File readFrom = new File(path, fileName);
        byte[] rtn = new byte[(int) readFrom.length()];
        try {
            FileInputStream stream = new FileInputStream(readFrom);
            stream.read(rtn);
            return new String(rtn);
        } catch (Exception e) {
            e.printStackTrace();
            return e.toString();
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        gui = findViewById(R.id.mapGui);
        mapLayout = findViewById(R.id.MapCT);
        scaleSlider = findViewById(R.id.ScaleSlider);
        addPOI = findViewById(R.id.AddPOI);
        clearPOI = findViewById(R.id.ClearPOI);
        deletPOI = findViewById(R.id.deletePOI);
        okButton = findViewById(R.id.okButton);
        newPOIname = findViewById(R.id.enteredPOIName);
        POInameView = findViewById(R.id.poiNameView);
        PopUpText = findViewById(R.id.PopUpText);
        PopUpTextChipGroup = findViewById(R.id.PopUp);
        PopUpTextOk = findViewById(R.id.PopUpOkButton);
        options = findViewById(R.id.Options);
        addOptions = findViewById(R.id.AddingPointOptions);

        try {
            // Sleep for 1 second (1000 milliseconds)
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            // Handle the exception if necessary
            e.printStackTrace();
        }

        PopUpTextChipGroup.setVisibility(View.GONE);
        options.setVisibility(View.GONE);
        addOptions.setVisibility(View.GONE);

        scaleSlider.setValueFrom(1f);
        scaleSlider.setValueTo(5f);
        scaleSlider.setValue(1f);

        gui.setMapScale(scaleSlider.getValue());

        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        locationListener = new GPSHandler();

        scaleSlider.addOnChangeListener(new Slider.OnChangeListener() {
            @Override
            public void onValueChange(@NonNull Slider slider, float value, boolean fromUser) {
                gui.setMapScale(scaleSlider.getValue());
            }
        });

        PopUpTextOk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                defaultVisibility();
            }
        });

        mapLayout.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                float mapScale = scaleSlider.getValue();
                int x = (int)event.getX();
                int y = (int)event.getY();


                ArrayList<int[]> POIs = new ArrayList<int[]>();
                for (double[] point :gui.getPOIs()) {
                    POIs.add(gui.convertToScreenCoordinates(point[0], point[1]));
                }
                if (isPointSelected && options.getVisibility() == View.VISIBLE)
                {
                    defaultVisibility();
                    isPointSelected = false;
                }
                if(!addingPOI && !POIs.isEmpty() && options.getVisibility() != View.VISIBLE)
                {
                    for (int[] point:POIs) {
                        float dictance = (float) Math.sqrt(Math.pow(((x - point[0])),2)+Math.pow(((y - point[1])),2));
                        System.out.println("Dic: "+dictance);
                        if(dictance < gui.getPoiRadius())
                        {
                            selectedPoint = point;
                            System.out.println("You Selected Point");

                            for (int[] points:POIs) {
                                if(selectedPoint == points){
                                    POInameView.setText(pointNames.get(POIs.indexOf(selectedPoint)));
                                    System.out.println(pointNames.get(0));
                                }
                            }
                            hideAll();
                            showPOIMenu();
                            isPointSelected = true;
                        }
                    }
                }
                if (scaleSlider.getValue() != 1 && !gui.getPOIs().isEmpty())
                {
                    PopUpText.setText("Zoom Must Be At One to Edit Point");
                    hideAll();
                    showPopUpView();
                }
                if(addingPOI)
                {
                    double[] poi = gui.convertScreenToCoordinates(x,y);
                    gui.addPOI(poi[0],poi[1]);
                    gui.addPersonPOI(lat, lon);
                    showEditPOIMenu();
                    addingPOI = false;
                }

                return false;
            }
        });

        addPOI.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(scaleSlider.getValue()==1){
                    isPointSelected = true;
                    addingPOI = true;
                    addPOI.setVisibility(View.GONE);
                    hideAll();
                } else {
                    PopUpText.setText("Zoom Must Be At One To Add Point Of Interest");
                    hideAll();
                    showPopUpView();
                }
            }
        });

        clearPOI.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                gui.clearPOI();
                gui.clearPOIAnchors();
                pointNames.clear();
                addingPOI = false;
            }
        });

        deletPOI.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(selectedPoint != null){
                    ArrayList<int[]> POIs = new ArrayList<int[]>();
                    for (double[] point :gui.getPOIs()) {
                        POIs.add(gui.convertToScreenCoordinates(point[0], point[1]));
                    }

                    for (int[] point:POIs) {
                        int count = 0;
                        if(point[0] == selectedPoint[0] && point[1] == selectedPoint[1])
                        {
                            pointNames.remove(count);
                            gui.removePOI(gui.getPOIs().get(count));
                            break;
                        }
                        count++;
                    }
                    defaultVisibility();
                    System.out.println("Deleted point");
                }
            }
        });

        okButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String poiName = newPOIname.getText().toString();
                System.out.println(poiName);
                pointNames.add(poiName);
                defaultVisibility();
                addPOI.setVisibility(View.VISIBLE);

                addingPOI = false;
                isPointSelected = false;
            }
        });





        // Check if the location permission is granted
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // Permission denied, request location updates
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 2);
            System.out.println("Permission Not granted");
        } else {
            // Permission not granted, request it from the user
            System.out.println("OJNSAODNAOIDSN");
            getLocation();
            System.out.println("Permission granted");
        }

        context = this;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permission granted, get and print location
                getLocation();
            } else {
                // Permission denied, handle accordingly
                // For example, display a message or disable location-dependent functionality
            }
        }
    }

    public static class Gyro implements SensorEventListener {
        private float[] vMag = new float[3];
        private float[] vAcc = new float[3];

        private boolean isAccelerometerDataValid = false;
        private boolean isMagnetometerDataValid = false;

        private float[] rotationMatrix = new float[9];
        private float[] orientationAngles = new float[3];

        private float deltaRotate = 0;
        private float previousRotation = 0;

        @Override
        public void onSensorChanged(SensorEvent event) {

            if (event == null) {
                return;
            }
            if (event.sensor.getType() == Sensor.TYPE_ACCELEROMETER) {
                vAcc = event.values.clone();
                isAccelerometerDataValid = true;
            } else if (event.sensor.getType() == Sensor.TYPE_MAGNETIC_FIELD) {
                vMag = event.values.clone();
                isMagnetometerDataValid = true;
            } else {
                isMagnetometerDataValid = false;
                isAccelerometerDataValid = false;
            }

            if (isMagnetometerDataValid && isAccelerometerDataValid) {
                SensorManager.getRotationMatrix(rotationMatrix, null, vAcc, vMag);
                SensorManager.getOrientation(rotationMatrix, orientationAngles);

                float azimuthInRadians = orientationAngles[0];
                float azimuthInDegrees = (float) Math.toDegrees(azimuthInRadians);

                // Calculate the rotation needed for the map to face north
                mapRotation = (360 - azimuthInDegrees) % 360;
                deltaRotate = Math.abs(mapRotation - previousRotation);
                if (!(deltaRotate <= 10)) {
                    gui.rotateMap((int) mapRotation);
                    previousRotation = mapRotation;
                    System.out.println("Rotate: " + mapRotation);
                }
            }
        }

        @Override
        public void onAccuracyChanged(Sensor sensor, int accuracy) {

        }
    }

    private class GPSHandler implements LocationListener {
        @Override
        public void onLocationChanged(@NonNull Location location) {

            System.err.println("EVENT");
            //Log.d("GPS", "LOCATION CHANGED:" + location.getLatitude() + " " + location.getLongitude());
            temp_path.add(location.getLatitude() + " " + location.getLongitude());
            lat = location.getLatitude();
            lon = location.getLongitude();
            gui.setPersonPos(lat,lon);
            //gui.setMapScale(scaleSlider.getValue());
            //System.out.println(scaleSlider.getValue());
            //gui.setPersonPos(35.72913026, -81.68718064);
        }
    }

    private void getLocation() {
        LocationManager locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        // Check if location services are enabled
        if (locationManager != null && locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
            // Request the last known location
            if (ActivityCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                String[] permissions = new String[] {Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION};
                requestPermissions(permissions, 2);
                return;
            }

            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 500, 1, locationListener);
            Location location = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            if (location != null) {
                double latitude = location.getLatitude();
                double longitude = location.getLongitude();
                gui.setPersonPos(latitude, longitude);
                gui.setPersonPos(latitude, longitude);
            } else {
                System.out.println("Location not available");
            }
        } else {
            System.out.println("Location services are disabled");
        }
    }

    private void showEditPOIMenu()
    {
        addOptions.setVisibility(View.VISIBLE);
    }

    private void hideEditPOIMenu()
    {
        addOptions.setVisibility(View.GONE);
    }

    private void showPOIMenu()
    {
        options.setVisibility(View.VISIBLE);
    }
    private void hidePOIMenu()
    {
        options.setVisibility(View.GONE);
    }
    private void showAddPointButton()
    {
        addPOI.setVisibility(View.VISIBLE);
    }
    private void hideAddPointButton()
    {
        addPOI.setVisibility(View.GONE);
    }
    private void hideAll()
    {
        hideAddPointButton();
        hidePOIMenu();
        hideEditPOIMenu();
        hideClear();
        hidePopUpView();
    }
    private void showPopUpView(){
        PopUpTextChipGroup.setVisibility(View.VISIBLE);
    }
    private void hidePopUpView(){
        PopUpTextChipGroup.setVisibility(View.GONE);
    }
    private void defaultVisibility()
    {
        hideEditPOIMenu();
        hidePOIMenu();
        hidePopUpView();
        showClear();
        showAddPointButton();
    }
    private void showClear()
    {
        clearPOI.setVisibility(View.VISIBLE);
    }
    private void hideClear()
    {
        clearPOI.setVisibility(View.GONE);
    }
}
