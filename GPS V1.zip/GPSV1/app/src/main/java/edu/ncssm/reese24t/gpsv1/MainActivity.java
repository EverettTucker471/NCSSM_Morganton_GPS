package edu.ncssm.reese24t.gpsv1;

import static com.google.android.material.math.MathUtils.lerp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.MailTo;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Objects;

import kotlin.math.UMathKt;

public class MainActivity extends AppCompatActivity {
    public static GUI gui;
    private static float mapRotation;

    Button startButton, endButton, poiButton, clearDataButton;
    TextView coordinateView, poiView;
    EditText nameInput;
    Logic l = new Logic();
    LocationManager locationManager;
    LocationListener locationListener;
    Context context;
    ArrayList<String> temp_path = new ArrayList<>();

    // This is some sample data from the
    String exampleData = "{\"ExampleEdge\":[\"43.00073166666667 -122.88323666666666\",\"43.003345 -122.87022\",\"43.00704833333333 -122.85957666666667\",\"43.00987166666667 -122.85271166666666\",\"43.017026666666666 -122.83983666666667\",\"43.021481666666666 -122.83314166666666\",\"43.02744333333333 -122.82610333333334\",\"43.032525 -122.82043833333333\",\"43.02592166666667 -122.80963833333334\"]}";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        gui = findViewById(R.id.MapGui);

        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        locationListener = new GPSHandler();

        context = this;

        if (ActivityCompat.checkSelfPermission(context, android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(context, android.Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            String[] permissions = new String[] {android.Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION};
            requestPermissions(permissions, 2);
            return;
        }
        locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 5000, 10, locationListener);
        Log.d("GPS", "ACCESS GRANTED");
        //gui.setTranslationY(500);
        //gui.moveMap(100,100);


    }

    public static class Gyro implements SensorEventListener
    {
        private float[] vMag = new float[3];
        private float[] vAcc = new float[3];

        private boolean isAccelerometerDataValid = false;
        private boolean isMagnetometerDataValid = false;

        private float[] rotationMatrix = new float[9];
        private float[] orientationAngles = new float[3];

        private float deltaRotate = 0;
        private float previousRotation = 0;

        @Override
        public void onSensorChanged(SensorEvent event) {
            if(event == null)
            {
                return;
            }
            if (event.sensor.getType() == Sensor.TYPE_ACCELEROMETER) {
                vAcc = event.values.clone();
                isAccelerometerDataValid = true;
            } else if (event.sensor.getType() == Sensor.TYPE_MAGNETIC_FIELD) {
                vMag = event.values.clone();
                isMagnetometerDataValid = true;
            } else {
                isMagnetometerDataValid = false;
                isAccelerometerDataValid = false;
            }

            if(isMagnetometerDataValid && isAccelerometerDataValid)
            {
                SensorManager.getRotationMatrix(rotationMatrix, null, vAcc, vMag);
                SensorManager.getOrientation(rotationMatrix, orientationAngles);

                float azimuthInRadians = orientationAngles[0];
                float azimuthInDegrees = (float) Math.toDegrees(azimuthInRadians);

                // Calculate the rotation needed for the map to face north
                mapRotation = (360 - azimuthInDegrees) % 360;
                deltaRotate = Math.abs(mapRotation - previousRotation);
                if(!(deltaRotate <= 10))
                {
                    gui.rotateMap((int) mapRotation);
                    previousRotation = mapRotation;
                    System.out.println("Rotate: "+mapRotation);
                }
            }
        }

        @Override
        public void onAccuracyChanged(Sensor sensor, int accuracy) {

        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        for (int i = 0; i < permissions.length; i++) {
            if (!Objects.equals(permissions[i], Manifest.permission.ACCESS_FINE_LOCATION) && grantResults[i] != PackageManager.PERMISSION_GRANTED) {
                Log.d("GPS", "NOT GRANTED" + grantResults[i]);
            }
        }
    }

    private class GPSHandler implements LocationListener {
        @Override
        public void onLocationChanged(@NonNull Location location) {
            Log.d("GPS", "LOCATION CHANGED:" + location.getLatitude() + " " + location.getLongitude());
            coordinateView.setText(location.getLatitude() + " " + location.getLongitude());
            temp_path.add(location.getLatitude() + " " + location.getLongitude());

            gui.setPersonPos(location.getLatitude(), location.getLongitude());
            System.out.println(location.getLatitude()+" : "+location.getLongitude());
        }
    }

}