package edu.ncssm.reese24t.gpsv1;

import androidx.annotation.NonNull;

public class PhysicalPoint {
    double latitude;
    double longitude;
    String name;

    public PhysicalPoint(double lat, double lon) {
        this.latitude = lat;
        this.longitude = lon;
    }

    public PhysicalPoint(double lat, double lon, String name) {
        this.latitude = lat;
        this.longitude = lon;
        if (name != null && !name.isEmpty()) {
            this.name = name;
        }
    }

    public boolean setLatitude(double latitude) {
        this.latitude = latitude;
        return true;
    }

    public boolean setLongitude(double longitude) {
        this.longitude = longitude;
        return true;
    }

    public double getLatitude() {
        return this.latitude;
    }

    public double getLongitude() {
        return this.longitude;
    }

    public double computeDistance(@NonNull PhysicalPoint p) {
        double lat1 = this.getLatitude();
        double lon1 = this.getLongitude();
        double lat2 = p.getLatitude();
        double lon2 = p.getLongitude();
        int radius = 6371000; // Earth's radius in meters
        double phi1 = Math.PI / 180 * lat1;
        double phi2 = Math.PI / 180 * lat2;
        double deltaPhi = Math.PI / 180 * (lat2 - lat1);
        double deltaLambda = Math.PI / 180 * (lon2 - lon1);
        double a = Math.pow(Math.sin(deltaPhi / 2), 2) + Math.cos(phi1) * Math.cos(phi2) * Math.pow(Math.sin(deltaLambda / 2), 2);
        return 2 * radius * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    }

    @NonNull
    public String toString() {
        return this.latitude + " " + this.longitude;
    }
}
