package edu.ncssm.reese24t.gpsv1;

import static android.content.Context.SENSOR_SERVICE;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.RotateDrawable;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Debug;
import android.util.AttributeSet;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;

public class GUI extends SurfaceView {

    private static int canvasWidth = 1800;
    private static int canvasHeight = 2207;
    private static int maplength;
    private static float mapScale;
    private static int mapRotation;
    private MainActivity.Gyro gyro;
    private final float schoolLength = 1841.02f;

    private int[] dAnchorpoint;
    private int[] rAnchorpoint;

    private static double minLongitude = -81.68939631296752;
    private static double maxLongitude  = -81.68518209872632;
    private static double minLatitude = 35.73190165046239;
    private static double maxLatitude = 35.726880384141765;

    private double latitude;
    private double longitude;

    public GUI(Context context) {
        super(context);
    }

    public GUI(Context context, AttributeSet attrs) {
        super(context, attrs);
        setWillNotDraw(false);

        SensorManager sensorManager = (SensorManager) context.getSystemService(SENSOR_SERVICE);
        Sensor sensorMag = sensorManager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD);
        Sensor sensorAcc = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        gyro = new MainActivity.Gyro();

        sensorManager.registerListener(gyro, sensorMag, SensorManager.SENSOR_DELAY_NORMAL);
        sensorManager.registerListener(gyro, sensorAcc, SensorManager.SENSOR_DELAY_NORMAL);
    }

    @Override
    protected void onDraw(Canvas c)
    {
        //Set the backround Color of the Canvas
        c.drawColor(Color.parseColor("#39b54a"));

        canvasWidth = c.getWidth();
        canvasHeight = c.getHeight();

        mapScale = 1f;

        if(canvasWidth > canvasHeight)
        {
            maplength = canvasWidth;
        } else
        {
            maplength = canvasHeight;
        }

        rAnchorpoint = new int[]{c.getWidth()/2,c.getHeight()/2};
        dAnchorpoint = new int[]{
                c.getWidth()/2 - (int)((maplength/2) * mapScale),
                c.getHeight()/2 - (int)((maplength/2) * mapScale)
        };

        //Paint color
        Paint p = new Paint();
        p.setColor(Color.RED);

        //Gets Map from Resource File
        Drawable d = ContextCompat.getDrawable(getContext(), R.drawable.gps_v1_map);

        Bitmap bitmap = Bitmap.createBitmap(maplength, maplength, Bitmap.Config.ARGB_8888);

        //Creates a Canvas with a specified bitmap to Drawl into
        Canvas bitmapCanvas = new Canvas(bitmap);
        bitmapCanvas.scale(mapScale,mapScale,rAnchorpoint[0],rAnchorpoint[1]);

        //Sets the position of the Drawable
        d.setBounds(dAnchorpoint[0], dAnchorpoint[1], dAnchorpoint[0] + (int)(maplength * mapScale), dAnchorpoint[1] + (int)(maplength * mapScale));

        //Drawls the Map onto the Bitmap Canvas
        d.draw(bitmapCanvas);
        //c.drawRect(0,0,c.getWidth(),(c.getHeight()/2)*conv, p);

        c.rotate(mapRotation, rAnchorpoint[0], rAnchorpoint[1]);
        System.out.println("("+rAnchorpoint[0]+", "+rAnchorpoint[1]+")");

        //Drawls the bitmap onto the main canvas
        c.drawBitmap(bitmap,0,0,null);

        System.out.println(latitude+" : "+longitude);
        int[] personPos = convertToScreenCoordinates(latitude, longitude);
        Paint personColor = new Paint(Color.BLUE);
        c.drawCircle(personPos[0], personPos[1], 15, personColor);
    }
    public void rotateMap(int newRotation)
    {
        this.mapRotation = newRotation;
        invalidate();
    }

    public int[] convertToScreenCoordinates(double latitude, double longitude) {
        int x = (int) ((longitude - this.minLongitude) / (this.maxLongitude - this.minLongitude) * canvasWidth);
        int y = (int) ((latitude - this.minLatitude) / (this.maxLatitude - this.minLatitude) *canvasHeight);
        return new int[]{x, y};
    }

    public void setPersonPos(double lat, double lon)
    {
        this.latitude = lat;
        this.longitude = lon;
        invalidate();
    }
}
