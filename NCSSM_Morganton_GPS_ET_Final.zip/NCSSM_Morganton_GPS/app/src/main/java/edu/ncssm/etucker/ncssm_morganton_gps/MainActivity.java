package edu.ncssm.etucker.ncssm_morganton_gps;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Objects;

public class MainActivity extends AppCompatActivity {
    // Creating buttons
    Button startButton, endButton, poiButton, clearDataButton;
    // Creating TextViews for coordinates and points of interest
    TextView coordinateView, poiView;
    // Creating a text input for the point of interest name
    EditText nameInput;
    // Creating a logic object
    Logic l = new Logic();
    LocationManager locationManager;
    LocationListener locationListener;
    // Creating a context variable to store context
    Context context;
    // location_list stores the location every time the location updates
    ArrayList<String> location_list = new ArrayList<>();

    // This is some example data for testing purposes
    String exampleData = "{\"Residence_Hall Academic_Commons\":[\"43.00073166666667 -122.88323666666666\",\"43.003345 -122.87022\",\"43.00704833333333 -122.85957666666667\",\"43.00987166666667 -122.85271166666666\",\"43.017026666666666 -122.83983666666667\",\"43.021481666666666 -122.83314166666666\",\"43.02744333333333 -122.82610333333334\",\"43.032525 -122.82043833333333\",\"43.02592166666667 -122.80963833333334\"]}\n{\"Residence_Hall Goodwin_Hall\":[\"43.019081666666665 -122.81272833333334\",\"37.45207833333333 -121.772245\",\"37.47387833333333 -121.68847333333333\",\"37.505478333333336 -121.59371666666667\",\"37.53053166666667 -121.47561333333333\",\"37.538155 -121.35476333333334\"]}";
    // This is real data that I recorded from NCSSM Morganton. Normally, this would be stored in a text file.
    String realLifeExampleData = "{\"AcademicCommons2 AcademicCommons1\":[\"35.7306672 -81.68686069\",\"35.73068026 -81.6868406\",\"35.73049773 -81.68664293\",\"35.73048934 -81.68665662\",\"35.73047187 -81.68662905\",\"35.73044066 -81.68660602\",\"35.73041523 -81.68659283\",\"35.73039968 -81.68658417\",\"35.73037988 -81.68658037\",\"35.73035935 -81.68657989\",\"35.73034802 -81.68658028\",\"35.73033786 -81.68658293\",\"35.73032761 -81.68658634\",\"35.73031914 -81.68659225\",\"35.73029819 -81.68658957\",\"35.73027207 -81.68659064\",\"35.7302486 -81.68658876\",\"35.73022521 -81.68658616\",\"35.73020345 -81.68657285\",\"35.73018244 -81.68656088\",\"35.73016158 -81.68655162\",\"35.73014089 -81.68654737\",\"35.73012356 -81.6865463\",\"35.73010904 -81.68654531\",\"35.73009286 -81.68655098\",\"35.7300775 -81.68655137\",\"35.73006569 -81.68655486\",\"35.73005089 -81.68656573\",\"35.73003711 -81.68657651\",\"35.73002023 -81.68658156\",\"35.7300019 -81.68658751\",\"35.72998572 -81.68659293\",\"35.72997088 -81.68659942\",\"35.72995741 -81.6866115\",\"35.72994823 -81.68662484\",\"35.72993821 -81.68663456\",\"35.72992723 -81.68664493\",\"35.72991474 -81.68665363\",\"35.72990153 -81.68666133\",\"35.72988808 -81.6866704\",\"35.72987288 -81.68667581\",\"35.72985562 -81.68668041\",\"35.72984024 -81.68668725\",\"35.72983042 -81.68669282\",\"35.72981761 -81.68670278\",\"35.72980819 -81.68670924\",\"35.7298006 -81.68671771\",\"35.72979449 -81.68672796\",\"35.72978235 -81.68672951\",\"35.72976816 -81.68672504\",\"35.72974982 -81.68671965\",\"35.72973333 -81.6867238\",\"35.7297203 -81.68673085\",\"35.72970819 -81.68674331\",\"35.72969205 -81.68675884\",\"35.72967824 -81.68677389\",\"35.72966661 -81.6867848\",\"35.72964849 -81.68679778\",\"35.72963304 -81.68680682\",\"35.72961876 -81.686813\",\"35.72960561 -81.68682034\",\"35.72958737 -81.68683481\",\"35.72957244 -81.68684295\",\"35.729561 -81.68685\",\"35.72955015 -81.68685869\",\"35.72954057 -81.68686679\",\"35.72953335 -81.68687586\",\"35.72952377 -81.68688607\",\"35.72950952 -81.68689561\",\"35.72949766 -81.68690059\",\"35.72947768 -81.6869091\",\"35.72946659 -81.68692128\",\"35.72945545 -81.68693192\",\"35.72944586 -81.6869438\",\"35.72943851 -81.68695704\",\"35.72943559 -81.68697198\",\"35.72943672 -81.68698847\",\"35.72943957 -81.68700478\",\"35.72944915 -81.6870162\",\"35.72946461 -81.68702556\",\"35.72948436 -81.68702924\",\"35.72950495 -81.68703056\",\"35.72952605 -81.6870286\"]}\n{\"GoodwinHall AcademicCommons2\":[\"35.73041749 -81.68658125\",\"35.730208 -81.6872616\",\"35.73042372 -81.6867766\",\"35.73040814 -81.68673652\",\"35.7304196 -81.68668858\",\"35.73042284 -81.68666468\",\"35.73042213 -81.68665005\",\"35.73042394 -81.68663582\",\"35.73043011 -81.68661373\",\"35.73043527 -81.68659583\",\"35.73043302 -81.68657579\",\"35.73042455 -81.68655728\",\"35.73041651 -81.68654895\",\"35.73040657 -81.6865498\",\"35.73039883 -81.68655816\",\"35.7303904 -81.68656577\",\"35.73037376 -81.68657012\",\"35.73036069 -81.68656934\",\"35.73036983 -81.68657362\",\"35.73038834 -81.6865751\",\"35.73040627 -81.68657732\",\"35.73041921 -81.68658178\"]}\n{\"ResidenceHall GoodwinHall\":[\"35.72900352 -81.68722012\",\"35.72901125 -81.68715667\",\"35.72900903 -81.68713695\",\"35.72899083 -81.68715035\",\"35.72900295 -81.68716297\",\"35.72899901 -81.68720231\",\"35.7290075 -81.68716221\",\"35.72903019 -81.68713797\",\"35.72904073 -81.68710466\",\"35.72905116 -81.6870936\",\"35.72905791 -81.68711342\",\"35.72905898 -81.68712727\",\"35.72906622 -81.68714836\",\"35.72906586 -81.68713547\",\"35.72907225 -81.68715449\",\"35.72907645 -81.68716891\",\"35.72911845 -81.68707956\",\"35.72912775 -81.68707104\",\"35.72914606 -81.68706748\",\"35.72916778 -81.68706887\",\"35.72917339 -81.68705747\",\"35.7291859 -81.6870258\",\"35.72922841 -81.68699407\",\"35.72926505 -81.68698593\",\"35.7292595 -81.68701083\",\"35.72929261 -81.68694786\",\"35.72931212 -81.68694109\",\"35.72933239 -81.68695433\",\"35.72934802 -81.68695503\",\"35.72936585 -81.68694578\",\"35.72938463 -81.68693298\",\"35.72940255 -81.68691961\",\"35.72940969 -81.68690471\",\"35.72941691 -81.68689265\",\"35.72942759 -81.68687795\",\"35.72944251 -81.6868627\",\"35.72945711 -81.68685398\",\"35.72947263 -81.6868466\",\"35.72949053 -81.6868401\",\"35.72950904 -81.68683475\",\"35.72952781 -81.68683049\",\"35.72954374 -81.68682803\",\"35.72955967 -81.68681685\",\"35.72957264 -81.68680584\",\"35.72958184 -81.6867963\",\"35.72959479 -81.68678327\",\"35.72960638 -81.68677501\",\"35.72961783 -81.68677019\",\"35.72963237 -81.68676564\",\"35.72965125 -81.6867613\",\"35.72966743 -81.68675628\",\"35.72967994 -81.68675382\",\"35.72969415 -81.68674955\",\"35.72971041 -81.68674165\",\"35.72972528 -81.6867341\",\"35.72973833 -81.68672365\",\"35.72975174 -81.68670977\",\"35.72976732 -81.68669812\",\"35.72978388 -81.68668963\",\"35.72979749 -81.68668668\",\"35.72980653 -81.68668244\",\"35.72982457 -81.68667781\",\"35.72984194 -81.6866731\",\"35.72985813 -81.68667329\",\"35.72987224 -81.686671\",\"35.72988618 -81.68666256\",\"35.72990082 -81.68665053\",\"35.72991901 -81.68663762\",\"35.72993382 -81.6866265\",\"35.72994467 -81.68661648\",\"35.72995212 -81.68660874\",\"35.72995905 -81.68659957\",\"35.72997043 -81.68659024\",\"35.72998261 -81.68658008\",\"35.72999629 -81.68657206\",\"35.73001119 -81.68656834\",\"35.73002992 -81.68656491\",\"35.73003994 -81.68656217\",\"35.73004871 -81.68655519\",\"35.73006178 -81.68654141\",\"35.73008226 -81.68653709\",\"35.73009652 -81.68654449\",\"35.7301114 -81.68654827\",\"35.73012313 -81.68655098\",\"35.73013384 -81.68654491\",\"35.73013975 -81.68653492\",\"35.73014942 -81.68653011\",\"35.73016106 -81.68652575\",\"35.73017614 -81.68651826\",\"35.73018934 -81.68651756\",\"35.73019982 -81.68651383\",\"35.73022207 -81.68651018\",\"35.73023835 -81.68651095\",\"35.73025664 -81.68651556\",\"35.73027412 -81.68652166\",\"35.73028728 -81.68652732\",\"35.73029906 -81.68653381\",\"35.7303089 -81.68653991\",\"35.73032214 -81.68654186\",\"35.73034376 -81.68654138\",\"35.73036797 -81.68653744\",\"35.7303856 -81.68653508\",\"35.73040538 -81.68653107\",\"35.73042134 -81.68652758\",\"35.73043444 -81.68652742\",\"35.73044587 -81.68652897\",\"35.73045616 -81.68652983\",\"35.73047411 -81.68651963\",\"35.73048944 -81.68651757\",\"35.73050231 -81.68651704\",\"35.73051968 -81.68651468\",\"35.73053829 -81.68650903\",\"35.73055572 -81.68650188\",\"35.73056358 -81.6864926\"]}\n{\"AcademicCommons1 ResidenceHall\":[\"35.72935551 -81.68713536\",\"35.72928707 -81.68735576\",\"35.72929308 -81.68730712\",\"35.72928972 -81.68729359\",\"35.72928395 -81.68727432\",\"35.72927142 -81.68727536\",\"35.72925907 -81.68728773\",\"35.72924301 -81.68732282\",\"35.72923274 -81.68734866\",\"35.72923817 -81.68736343\",\"35.72928443 -81.68737977\",\"35.72934527 -81.68733574\",\"35.72936937 -81.68731923\",\"35.72938624 -81.68731101\",\"35.7293773 -81.68730804\",\"35.72936437 -81.68729993\",\"35.72935647 -81.68729382\",\"35.72935093 -81.6872829\",\"35.72934475 -81.68727116\",\"35.72933291 -81.68725575\",\"35.72932675 -81.68724681\",\"35.72932008 -81.68723879\",\"35.72930537 -81.68722779\",\"35.72929115 -81.68722007\",\"35.72927484 -81.68721315\",\"35.72926572 -81.68721069\",\"35.72925661 -81.68720816\",\"35.72924646 -81.68720669\",\"35.72923621 -81.68720575\",\"35.72922599 -81.68720511\",\"35.72921548 -81.68720496\",\"35.72920483 -81.68720429\",\"35.72919338 -81.68720306\",\"35.72918179 -81.68720047\",\"35.72917229 -81.68719701\",\"35.72916074 -81.68719022\",\"35.72914835 -81.68718159\",\"35.72913557 -81.68717254\",\"35.72912178 -81.68716323\",\"35.72911023 -81.68715691\",\"35.72910344 -81.6871402\",\"35.72910293 -81.68712308\",\"35.72910148 -81.68710916\",\"35.72909678 -81.6871248\",\"35.72910271 -81.68714057\",\"35.72909377 -81.68715677\",\"35.72908466 -81.68716645\"]}";

    /**
     * Takes coordinates, converts them into a JSON object, then stores that object in a text file
     *
     * @param path_name the name of the path you want to create
     * @param path an ArrayList containing Strings with latitude and longitude separated by a space
     * @throws JSONException if there is an error creating the JSON
     * @throws IOException if there is an error writing text to the file
     */
    private void writeJSON(String path_name, ArrayList<String> path) throws JSONException, IOException {
        try {
            // Creates a new JSONObject and a JSONArray
            JSONObject physicalEdges = new JSONObject();
            JSONArray json_path = new JSONArray();

            // Puts every coordinate pair in the JSONArray object
            for (int i = 0; i < path.size(); i++) {
                json_path.put(path.get(i));
            }

            // Puts the JSONArray object into a JSONObject with the name path_name
            physicalEdges.put(path_name, json_path);
            Log.d("JSON", physicalEdges.toString());

            // String for putting data into the text file
            String jsonPathString = physicalEdges.toString();

            // Calling the writeToFile method to put the jsonString into PhysicalEdges.txt
            writeToFile("PhysicalEdges.txt", readFromFile("PhysicalEdges.txt") + " \n " + jsonPathString);
            Log.d("OUTPUT", readFromFile("PhysicalEdges.txt"));

        } catch (JSONException e) {
            // Runs if there is an issue creating the JSON objects
            e.printStackTrace();
            Log.d("JSON", "JSON Error");
        }
    }

    /**
     * Writes a string in a file, overwrites any existing data
     *
     * @param fileName the name of the file you are writing to
     * @param contents a string which is contains the material to be written
     */
    private void writeToFile(String fileName, String contents) {
        // Creates the file path from the app
        File file_path = getApplicationContext().getFilesDir();
        try {
            // Creates a new file writer using the file path and the file name
            FileOutputStream writer = new FileOutputStream(new File(file_path, fileName));

            // Writes contents to the file
            writer.write(contents.getBytes());

            writer.close();
            Log.d("FILE", "File Written to txt");
        } catch (Exception e) {
            // This runs if there was an error writing contents to the file
            e.printStackTrace();
        }
    }

    /**
     * Returns the contents of a text file as a String
     *
     * @param fileName the name of the file you want to read
     * @return the contents of the file as a String
     */
    @NonNull
    private String readFromFile(String fileName) {
        // Gets the file paths from the app
        File path = getApplicationContext().getFilesDir();

        // Creates a new file from the file paths and the provided name
        File readFrom = new File(path, fileName);

        // Creates a byte array to store the extracted data from the file
        byte[] rtn = new byte[(int) readFrom.length()];
        try {
            // Creates a new file input stream to get the file contents
            FileInputStream stream = new FileInputStream(readFrom);

            // Reads the file contents into rtn
            stream.read(rtn);

            // Casts the byte[] into a String and returns it
            return new String(rtn);
        } catch (Exception e) {
            // This runs if there was a issue finding the file specified
            e.printStackTrace();
            return e.toString();
        }
    }


    /**
     * This method runs when the application is created
     *
     * @param savedInstanceState the settings of the app when started
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initializes a location manager from system services
        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);

        // Initializes a new location listener to detect changes in location
        locationListener = new GPSHandler();

        // Initializes the text outputs
        coordinateView = findViewById(R.id.coordinateView);
        poiView = findViewById(R.id.poiView);
        nameInput = findViewById(R.id.edgeNameInput);

        // Stores the current context
        context = this;

        // Initializes the start button
        startButton = findViewById(R.id.startRecordingButton);

        // Creates the click listener for the start button
        startButton.setOnClickListener(new View.OnClickListener() {
            /**
             * This method is called every time the start button is clicked
             *
             * @param view the screen the button is on
             */
            @Override
            public void onClick(View view) {
                // Checks if the device's permissions match the permissions found in android_manifest
                if (ActivityCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                    // If the device's permissions don't match the permissions in android_manifest, send a request permissions with the required permissions
                    String[] permissions = new String[] {Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION};
                    requestPermissions(permissions, 2);
                    return;
                }
                // Start location updates with a minimum time of half a second and a minimum distance of one meter
                locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 500, 1, locationListener);
                Log.d("GPS", "ACCESS GRANTED");

                // Create the JSONObjects from the real-world example data
                try {
                    // Parse the real example data and create a new physical edge
                    for (String str : realLifeExampleData.split("\n", realLifeExampleData.length())) {
                        JSONObject json = new JSONObject(str);
                        l.addPhysicalEdge(json);
                        Log.d("JSON", json.toString());
                    }
                    // Print the new edge
                    for (int i = 0; i < l.getEdgeListLength(); i++) {
                        Log.d("toString", l.getPhysicalEdges().get(i).toString());
                    }
                    // Create a graph using the data inside l and display the graph
                    l.createGraph("G").displayGraph();
                } catch (JSONException e) {
                    // This runs if there is a problem creating the JSON objects
                    throw new RuntimeException(e);
                }
            }
        });

        // Initializes the end button
        endButton = findViewById(R.id.endRecordingButton);

        // Sets the on click listener for the end button
        endButton.setOnClickListener(new View.OnClickListener() {
            /**
             * This method is run every time the end button is clicked
             *
             * @param view the screen the end button is on
             */
            @Override
            public void onClick(View view) {
                // Stop location updates
                locationManager.removeUpdates(locationListener);

                try {
                    // Write a JSON using the data inside the name input and the data inside location_list
                    writeJSON(String.valueOf(nameInput.getText()), location_list);
                    System.out.println("JSON Written Successfully");
                } catch (JSONException | IOException e) {
                    // This runs if there is a error writing the JSON or an error writing to the text file
                    System.out.println("JSON or IO Error");
                    throw new RuntimeException(e);
                }
                // Clear the location list
                location_list.clear();

                // Clear the name input
                nameInput.setText("");
            }
        });

        // Initializes the point of interest button
        poiButton = findViewById(R.id.poiButton);

        // Sets the on click listener for the point of interest button
        poiButton.setOnClickListener(new View.OnClickListener() {
            /**
             * This method is called every time the point of interest button is clicked
             *
             * @param view the screen that the point of interest button is on
             */
            @Override
            public void onClick(View view) {
                // Store the most current coordinates in a string
                String poi = location_list.get(location_list.size() - 1);

                // Create a JSONObject of the most current location
                JSONObject json = new JSONObject();

                try {
                    // Name the point of interest using the data from the name input
                    json.put((String) poiView.getText(), poi);

                    // Display the point of interest
                    poiView.setText(json.toString());

                    // writes the point of interest to the file storing points of interest
                    writeToFile("PointsOfInterest.txt", readFromFile("PointsOfInterest")+ json);
                    Log.d("FILE", "Point of interest written"+json);
                } catch (JSONException e) {
                    // This runs if there is an error creating the JSONObject
                    e.printStackTrace();
                    throw new RuntimeException(e);
                }
            }
        });

        // Initializes the clear data button
        clearDataButton = findViewById(R.id.clearEverythingButton);

        // Creates an on click listener for the clear data button
        clearDataButton.setOnClickListener(new View.OnClickListener() {
            /**
             * This method is run every time the clear data button is clicked
             * It clears all the text inputs and files
             *
             * @param view the screen that the clear data button is on
             */
            @Override
            public void onClick(View view) {
                // Clear the points of interest and physical edges files
                writeToFile("PointsOfInterest.txt", "");
                writeToFile("PhysicalEdges.txt", "");
                Log.d("DATA", "ALL DATA CLEARED");
            }
        });
    }

    /**
     * This method runs after the requestPermissions method outputs updated permissions
     *
     * @param requestCode The request code passed from the requestPermissions method
     * @param permissions The requested permissions. Never null.
     * @param grantResults The grant results for the corresponding permissions
     *     which is either {@link android.content.pm.PackageManager#PERMISSION_GRANTED}
     *     or {@link android.content.pm.PackageManager#PERMISSION_DENIED}. Never null.
     *
     */
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        // Check if every permission in permissions equals the permission found in android_manifest
        for (int i = 0; i < permissions.length; i++) {
            if (!Objects.equals(permissions[i], Manifest.permission.ACCESS_FINE_LOCATION) && grantResults[i] != PackageManager.PERMISSION_GRANTED) {
                // If the permission in the app doesn't match the permission in android_manifest, print an error message
                Log.d("GPS", "NOT GRANTED" + grantResults[i]);
            }
        }
    }

    private class GPSHandler implements LocationListener {
        /**
         * This method is called when the location meets the criteria for an update
         *
         * @param location the location found by the GPS
         */
        @Override
        public void onLocationChanged(@NonNull Location location) {
            Log.d("GPS", "LOCATION CHANGED:" + location.getLatitude() + " " + location.getLongitude());

            // Shows the coordinates in the coordinate view
            coordinateView.setText(location.getLatitude() + " " + location.getLongitude());

            // Adds the coordinates to the location_list with a space as a delimiter
            location_list.add(location.getLatitude() + " " + location.getLongitude());
        }
    }
}