package edu.ncssm.etucker.ncssm_morganton_gps;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class Vertex {
    private List<Vertex> neighbors;
    private String name;
    private final double id = Math.random();
    /**
     * Default constructor to create a vertex
     */
    public Vertex() {
        neighbors = new ArrayList<Vertex>();
        name = "";
    }

    /**
     * Constructor taking a name
     *
     * @param name the name of the vertex
     */
    public Vertex(String name) {
        this.name = Objects.requireNonNullElse(name, "");
        neighbors = new ArrayList<Vertex>();
    }

    /**
     * Constructor taking neighbors
     *
     * @param neighbors the neighbors of the vertex. The neighbors are not copied.
     */
    public Vertex(List<Vertex> neighbors) {
        setNeighbors(neighbors);
        this.name = "";
    }

    /**
     * Constructor taking a name and neighbors
     *
     * @param name      the name of the vertex
     * @param neighbors the adjacent vertices of this vertex
     */
    public Vertex(String name, List<Vertex> neighbors) {
        setNeighbors(neighbors);
        this.name = Objects.requireNonNullElse(name, "");
    }

    /**
     * Renames the vertex
     *
     * @param name the new name of the vertex
     * @return boolean indicating change
     */
    public boolean setName(String name) {
        boolean rtn = true;
        if (name != null) {
            this.name = name;
        } else {
            rtn = false;
        }
        return rtn;
    }

    /**
     * Precondition: neighbors consists of distinct vertices
     * Sets the neighbors of the vertex
     *
     * @param neighbors the neighbors of the vertex to set
     * @return a boolean indicating change
     */
    public boolean setNeighbors(List<Vertex> neighbors) {
        this.neighbors = new ArrayList<Vertex>();
        if (neighbors != null) {
            this.neighbors.addAll(neighbors);
        }
        return true;
    }

    /**
     * Adds a new neighbor not in neighbors to neighbors
     *
     * @param neighbor the new neighbor to add
     * @return the boolean indicating change
     */
    private boolean sidedAddNeighbor(Vertex neighbor) {
        boolean rtn = true;
        for (Vertex vert : neighbors) {
            if (vert == neighbor) {
                rtn = false;
                break;
            }
        }
        if (rtn) {
            neighbors.add(neighbor);
        }
        return rtn;
    }

    /**
     * Bidirectional sidedAddNeighbor
     *
     * @param neighbor the neighbor to add
     * @return the boolean indicating change
     */
    public boolean addNeighbor(Vertex neighbor) {
        boolean rtn = true;
        for (Vertex vert : neighbors) {
            if (vert == neighbor) {
                rtn = false;
                break;
            }
        }
        if (rtn) {
            this.sidedAddNeighbor(neighbor);
            neighbor.sidedAddNeighbor(this);
        }
        return rtn;
    }

    /**
     * Adds the new neighbors
     *
     * @param neighbors the neighbors to add to the current neighbors
     */
    public void addNeighbors(List<Vertex> neighbors) {
        if (neighbors != null) {
            for (Vertex vert : neighbors) {
                this.addNeighbor(vert);
            }
        }
    }

    /**
     * Removes a vertex neighbor, if it is present
     *
     * @param neighbor the neighbor to remove
     * @return the boolean indicating removal
     */
    private boolean sidedRemoveNeighbor(Vertex neighbor) {
        if (neighbor != null) {
            return neighbors.remove(neighbor);
        } else {
            return false;
        }
    }

    /**
     * Bidirectional sidedRemoveNeighbor
     *
     * @param neighbor the neighbor to remove
     * @return the boolean indicating change
     */
    public boolean removeNeighbor(Vertex neighbor) {
        if (neighbor != null) {
            neighbor.sidedRemoveNeighbor(this);
            return this.sidedRemoveNeighbor(neighbor);
        } else {
            return false;
        }
    }

    /**
     * Removes the neighbors to be removed
     *
     * @param neighbors the neighbors to be removed
     */
    public void removeNeighbors(List<Vertex> neighbors) {
        if (neighbors != null) {
            for (Vertex vert : neighbors) {
                this.removeNeighbor(vert);
            }
        }
    }

    /**
     * ID for the Vertex for primitive type reference
     *
     * @return ID of Vertex
     */
    public double getID() {
        return id;
    }

    /**
     * Getter for name of vertex
     *
     * @return the name of the Vertex
     */
    public String getName() {
        return this.name;
    }

    /**
     * For debugging purposes by printing the names of the neighbors
     */
    public void displayNeighbors() {
        System.out.print("The neighbors of " + this.getName() + " are: ");
        for (Vertex vert : neighbors) {
            System.out.print(vert.getName() + " ");
        }
        System.out.print("\n");
    }

    /**
     * Getter for array of IDs of neighbors
     * @return the neighbors ID array
     */
    public double[] neighborIDs() {
        int numNeighbors = neighbors.size();
        double[] rtn = new double[numNeighbors];
        for (int i = 0; i < numNeighbors; i++) {
            rtn[i] = neighbors.get(i).getID();
        }
        return rtn;
    }

    /**
     * String representation of vertex
     * @return the name of the vertex
     */
    public String toString() {
        return this.getName();
    }

}