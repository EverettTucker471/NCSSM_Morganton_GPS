package edu.ncssm.etucker.ncssm_morganton_gps;

import java.util.*;
public class DistanceReference {
    private Map<Vertex, Double> dist;
    private Map<Vertex, Vertex> prev;

    /**
     * Used for encapsulating return from Dijkstra's
     * @param dist the vertex-distance map
     * @param prev the vertex-vertex map
     */
    public DistanceReference(Map<Vertex, Double> dist, Map<Vertex, Vertex> prev) {
        setDistance(dist);
        setPrev(prev);
    }

    private boolean setDistance(Map<Vertex, Double> dist) {
        if (dist == null) {
            throw new IllegalArgumentException("dist should be nonnull");
        } else {
            this.dist = dist;
            return true;
        }
    }

    private boolean setPrev(Map<Vertex, Vertex> prev) {
        if (prev == null) {
            throw new IllegalArgumentException("prev should be nonnull");
        } else {
            this.prev = prev;
            return true;
        }
    }

    /**
     * Accessor for dist
     * @return dist
     */
    public Map<Vertex, Double> getDist() {
        return this.dist;
    }

    /**
     * Accessor for prev
     * @return prev
     */
    public Map<Vertex, Vertex> getPrev() {
        return this.prev;
    }
}
