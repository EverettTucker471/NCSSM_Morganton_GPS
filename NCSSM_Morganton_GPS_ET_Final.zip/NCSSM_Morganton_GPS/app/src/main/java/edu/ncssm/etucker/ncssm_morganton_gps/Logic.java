package edu.ncssm.etucker.ncssm_morganton_gps;

import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

/**
 * This class stores all the objects representing location of edges and points of interest
 */
public class Logic {
    // Initializes the list to store edges
    private ArrayList<PhysicalEdge> physicalEdgeList = new ArrayList<>();
    // Initializes the list to store points of interest
    private ArrayList<PhysicalPoint> physicalPointList = new ArrayList<>();

    /**
     * Default constructor taking no arguments
     */
    public Logic() {}

    /**
     * Returns the physical edges stored in logic
     * @return an ArrayList of PhysicalEdge objects
     */
    public ArrayList<PhysicalEdge> getPhysicalEdges() {
        return physicalEdgeList;
    }

    /**
     * Returns the points of interest stored in logic
     * @return an ArrayList of PhysicalPoint objects
     */
    public ArrayList<PhysicalPoint> getPhysicalPoints() {
        return physicalPointList;
    }

    /**
     * Adds a new PhysicalPoint object to physicalPointList
     * @param lat the latitude of the point
     * @param lon the longitude of the point
     * @return true
     */
    public boolean addPointOfInterest(double lat, double lon) {
        physicalPointList.add(new PhysicalPoint(lat, lon));
        return true;
    }

    /**
     * Creates a new PhysicalEdge object from a JSONObject
     * @param json a JSONObject storing an edge
     * @throws JSONException if there is an error parsing the JSONObject
     */
    public void addPhysicalEdge(JSONObject json) throws JSONException {
        // Gets the last key in json, there should only be one key in json
        String key = json.keys().next();
        // Get the start name of the path
        String start = key.split(" ", 2)[0];
        // Get the end name of the path
        String end = key.split(" ", 2)[1];

        // Get the JSONArray the corresponds to the key, there should only be one
        JSONArray arr = json.getJSONArray(key);
        ArrayList<PhysicalPoint> point_list = new ArrayList<>();

        // For coordinate pair in the JSONArray, parse it for a double and create a new PhysicalPoint object
        // Add that PhysicalPoint object to the temporary point_list
        for (int i = 0; i < arr.length(); i++) {
            String[] lat_lon = ((String) arr.get(i)).split(" ", 2);
            PhysicalPoint temp_point = new PhysicalPoint(Double.parseDouble(lat_lon[0]), Double.parseDouble(lat_lon[1]));
            point_list.add(temp_point);
        }
        // Create a edge using the data gathered from parsing the JSON and add it to the physicalEdgeList
        physicalEdgeList.add(new PhysicalEdge(point_list, start, end));
        // Traverse the JSONArray and create a new edge with the coordinates
    }

    /**
     * Takes the elements inside the physicalEdgeList and turns them into graph objects
     * @param name the name of the graph
     * @return the completed graph
     */
    public Graph createGraph(String name) {
        // Initialize the hashmap and the vertex list
        Map<Vertex[], Double> map = new HashMap<>();
        List<Vertex> vertexList = new ArrayList<>();

        // Parsing the physicalEdgeList to extract a SET of vertices --> no duplicates
        for (PhysicalEdge edge : physicalEdgeList) {
            // Getting the start and end vertices from the edge
            Vertex v1 = new Vertex(edge.getStart());
            Vertex v2 = new Vertex(edge.getEnd());

            // adding the vertex if it is not already in the vertex list
            if (!(contains(vertexList, v1))) {
                vertexList.add(v1);
            }
            if (!(contains(vertexList, v2))) {
                vertexList.add(v2);
            }
        }

        // Creating the hashmap
        for (PhysicalEdge edge : physicalEdgeList) {
            Vertex start = null;
            Vertex end = null;

            // Finding the vertices that correspond with the edge
            for (Vertex vertex : vertexList) {
                if (Objects.equals(vertex.getName(), edge.getStart())) {
                    start = vertex;
                }
                if (Objects.equals(vertex.getName(), edge.getEnd())) {
                    end = vertex;
                }
            }
            // Putting the vertices and distance pair into the hashmap
            map.put(new Vertex[]{start, end}, edge.getDistance());
        }
        // Printing the vertex list and hashmap
        Log.d("Vertex List: ", vertexList.toString());
        for (Vertex[] key : map.keySet()) {
            Log.d("Hashmap", key[0].toString() + " " + key[1].toString());
        }
        // creating and returning the new graph
        return new Graph(name, vertexList, map);
    }

    /**
     * Helper method to determine if a vertex exists in vertices with the same name as another vertex v
     *
     * @param vertices the list of vertices to check
     * @param v the vertex you are looking for
     * @return boolean, true if there is a vertex in vertices with the same name as v
     */
    private boolean contains(List<Vertex> vertices, Vertex v) {
        ArrayList<String> s = new ArrayList<>();
        // Putting all the vertex names into an array list
        for (Vertex vertex : vertices) {
            s.add(vertex.getName());
        }
        // Return true if that array list contains the name of vertex v
        return s.contains(v.getName());
    }

    /**
     * Adds a point of interest from a JSONObject
     *
     * @param json the JSONObject containing point data
     * @throws JSONException if there is an error creating the JSON file
     */
    public void addPoint(JSONObject json) throws JSONException {
        // Gets the only key in json.keys()
        String key = json.keys().next();
        // Gets the array corresponding to that key, there is only one array
        JSONArray arr = json.getJSONArray(key);
        // Creates a physical point with the data from the json array
        physicalPointList.add(new PhysicalPoint((Double) arr.get(0), (Double) arr.get(1)));
    }

    /**
     * This function initializes all the paths when the app is launched
     *
     * @param edge_string the string of data from the text file
     * @throws JSONException if there is an error creating the JSONObject
     */
    public void initializeEdges(String edge_string) throws JSONException {
        // For edge in edge_string, create a new JSONObject and use that to create a new PhysicalEdge
        for (String e : edge_string.split("\n", edge_string.length())) {
            JSONObject json = new JSONObject(e);
            addPhysicalEdge(json);
        }
    }

    /**
     * This initializes the points of interest when the app is launched
     *
     * @param point_string the string of point of interest data from the text file
     * @throws JSONException if there is an error creating the JSONObjects
     */
    public void initializePoints(String point_string) throws JSONException {
        // For point in point_string, create a new JSONObject and use that to create a new PhysicalPoint
        for (String p : point_string.split("\n", point_string.length())) {
            JSONObject json = new JSONObject(p);
            addPoint(json);
        }
    }

    /**
     * Returns the distance of an edge from its index in physicalEdgeList
     *
     * @param index the index of the desired edge
     * @return double of the distance of the edge if defined, 0 otherwise
     */
    public double getDistanceFromIndex(int index) {
        if (index >= 0 && index < physicalEdgeList.size()) {
            return physicalEdgeList.get(index).getDistance();
        }
        return 0;
    }

    /**
     * Returns the length of the physicalEdgeList
     *
     * @return int, the length of the physicalEdgeList
     */
    public int getEdgeListLength() {
        return this.physicalEdgeList.size();
    }
}
