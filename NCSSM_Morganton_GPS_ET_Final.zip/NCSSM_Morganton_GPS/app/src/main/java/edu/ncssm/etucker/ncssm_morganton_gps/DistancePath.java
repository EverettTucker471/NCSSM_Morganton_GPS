package edu.ncssm.etucker.ncssm_morganton_gps;

import java.util.*;
public class DistancePath {
    private double distance;
    private List<Vertex> path;

    /**
     * Encapsulator for return of shortestDistance method of graph
     * @param distance the distance between the two points
     * @param path the sequence of vertices
     */
    public DistancePath(double distance, List<Vertex> path) {
        this.distance = distance;
        this.path = path;
    }

    private boolean setPath(List<Vertex> path) {
        if (path != null) {
            this.path = path;
            return true;
        } else {
            throw new IllegalArgumentException("path should be nonnull");
        }
    }

    /**
     * getter for distance
     * @return the distance
     */
    public double getDistance() {
        return distance;
    }

    /**
     * getter for path
     * @return the path
     */
    public List<Vertex> getPath() {
        return path;
    }
}