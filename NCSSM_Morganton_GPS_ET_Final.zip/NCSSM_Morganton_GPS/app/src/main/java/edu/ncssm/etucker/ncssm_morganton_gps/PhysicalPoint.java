package edu.ncssm.etucker.ncssm_morganton_gps;

import androidx.annotation.NonNull;

/**
 * PhysicalPoint stores data about the longitude, latitude, and name of a physical point
 */
public class PhysicalPoint {
    double latitude;
    double longitude;
    String name;

    /**
     * Constructor that takes a latitude and a longitude
     * @param lat the longitude of the point as a double
     * @param lon the latitude of the point as a double
     */
    public PhysicalPoint(double lat, double lon) {
        this.latitude = lat;
        this.longitude = lon;
    }

    /**
     * Constructor that takes a latitude, longitude, and name
     * @param lat the latitude of the point as a double
     * @param lon the longitude of the point as a double
     * @param name the name of the point as a String
     */
    public PhysicalPoint(double lat, double lon, String name) {
        this.latitude = lat;
        this.longitude = lon;
        if (name != null && !name.isEmpty()) {
            this.name = name;
        }
    }

    /**
     * Sets the latitude of a point
     * @param latitude the latitude of the point as a double
     * @return true
     */
    public boolean setLatitude(double latitude) {
        this.latitude = latitude;
        return true;
    }

    /**
     * Sets the longitude of the point
     * @param longitude the longitude of the point as a double
     * @return true
     */
    public boolean setLongitude(double longitude) {
        this.longitude = longitude;
        return true;
    }

    /**
     * @return the latitude of the point
     */
    public double getLatitude() {
        return this.latitude;
    }

    /**
     * @return the longitude of the point
     */
    public double getLongitude() {
        return this.longitude;
    }

    /**
     * Returns the distance between two points using the haversine formula
     * I tried to optimize this formula for speed, not memory
     * @param p the other point as a PhysicalPoint
     * @return the distance between the points in meters as a double
     */
    public double computeDistance(@NonNull PhysicalPoint p) {
        double lat1 = this.getLatitude();
        double lon1 = this.getLongitude();
        double lat2 = p.getLatitude();
        double lon2 = p.getLongitude();
        int radius = 6371000; // Earth's radius in meters
        double phi1 = Math.PI / 180 * lat1;
        double phi2 = Math.PI / 180 * lat2;
        double deltaPhi = Math.PI / 180 * (lat2 - lat1);
        double deltaLambda = Math.PI / 180 * (lon2 - lon1);
        double a = Math.pow(Math.sin(deltaPhi / 2), 2) + Math.cos(phi1) * Math.cos(phi2) * Math.pow(Math.sin(deltaLambda / 2), 2);
        return 2 * radius * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    }

    /**
     * @return a string displaying the latitude and longitude of the point
     */
    @NonNull
    public String toString() {
        return this.latitude + " " + this.longitude;
    }
}
