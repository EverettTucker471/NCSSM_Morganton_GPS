package edu.ncssm.etucker.ncssm_morganton_gps;

import java.util.ArrayList;

/**
 * PhysicalEdge stores latitude and longitude data about edges
 */
public class PhysicalEdge {
    // Each edge is made up of a collection of PhysicalPoints
    private ArrayList<PhysicalPoint> points = new ArrayList<>();
    // Each edge has a double distance
    private double distance;
    // Start vertex, used to construct the graph
    private String start;
    // End vertex, used to construct the graph
    private String end;

    /**
     * PhysicalEdge constructor that takes a PhysicalPoint list, a start string, and an end string
     *
     * @param p an ArrayList of PhysicalPoints in the edge
     * @param s a String for the start of the edge
     * @param e a String for the end of the edge
     */
    public PhysicalEdge(ArrayList<PhysicalPoint> p, String s, String e) {
        if (p != null && p.size() > 0) {
            this.points.addAll(p);
        } else {
            throw new IllegalArgumentException("Physical point array should be nonnull");
        }
        if (s != null && !s.isEmpty()) {
            this.start = s;
        }
        if (e != null && !e.isEmpty()) {
            this.end = e;
        }
        this.distance = this.findDistance();
    }

    /**
     * Computes the distance of the path by considering the sum of distances between successive points
     *
     * @return the distance of the edge as a double
     */
    public double findDistance() {
        double rtn = 0;
        // For each successive pair of points, add the distance to the total
        for (int i = 0; i < this.points.size() - 1; i++) {
            rtn += this.points.get(i).computeDistance(this.points.get(i+1));
        }
        return rtn;
    }

    /**
     *
     * @return the distance of the edge as a double
     */
    public double getDistance() {
        return this.distance;
    }

    /**
     * Sets the start of an edge
     *
     * @param s the start of the edge as a String
     * @return if the start String is valid as a boolean
     */
    public boolean setStart(String s) {
        boolean rtn = false;
        if (s != null && !s.isEmpty()) {
            this.start = s;
            rtn = true;
        }
        return rtn;
    }

    /**
     * Sets the points of an edge from an ArrayList of PhysicalPoints
     *
     * @param p an ArrayList of PhysicalPoints to be included in the path
     * @return if the ArrayList is valid as a boolean
     */
    public boolean setPoints(ArrayList<PhysicalPoint> p) {
        boolean rtn = false;
        if (p != null) {
            this.points.addAll(p);
            rtn = true;
        }
        return rtn;
    }

    /**
     *
     * @return a String with the start, end, distance, and points in an edge
     */
    public String toString() {
        StringBuilder rtn = new StringBuilder("Start: " + this.start + " End: " + this.end + " Distance: " + this.distance + " Points: ");
        for (int i = 0; i < this.points.size(); i++) {
            rtn.append(this.points.get(i).toString());
        }
        return rtn.toString();
    }

    /**
     * Sets the end of an edge
     *
     * @param e the end of the edge as a String
     * @return if the end String is valid as a boolean
     */
    public boolean setEnd(String e) {
        boolean rtn = false;
        if (e != null && !e.isEmpty()) {
            this.end = e;
            rtn = true;
        }
        return rtn;
    }

    /**
     * @return the start of an edge as a String
     */
    public String getStart() {
        return this.start;
    }

    /**
     * @return the end of en edge as a String
     */
    public String getEnd() {
        return this.end;
    }
}
